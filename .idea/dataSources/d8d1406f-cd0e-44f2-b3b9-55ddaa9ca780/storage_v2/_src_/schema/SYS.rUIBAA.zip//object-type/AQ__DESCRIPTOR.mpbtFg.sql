create TYPE     aq$_descriptor AS OBJECT (
        queue_name       VARCHAR2(65),                -- name of the queue
        consumer_name    VARCHAR2(30),                -- name of the consumer
        msg_id           RAW(16),                     -- message identifier
        msg_prop         msg_prop_t,                  -- message properties
        gen_desc         sys.aq$_ntfn_descriptor,     -- generic descriptor
        msgid_array      sys.aq$_ntfn_msgid_array,    -- grp ntfn msgid list
        ntfnsRecdInGrp   NUMBER)                      -- ntfns recd in grp
/

