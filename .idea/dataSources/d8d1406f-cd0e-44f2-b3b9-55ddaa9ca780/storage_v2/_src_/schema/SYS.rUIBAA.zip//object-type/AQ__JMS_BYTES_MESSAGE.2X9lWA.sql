create type aq$_jms_bytes_message
                                       wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
84 b2
BqFD6cKH3W4nNYwL8NBQCEExrY4wg5n0dLhcWlbD9HKXYkqu5VahYkpyLmLR3FmuXI/AdCul
v5vAMsvuJY8JaaW4MvVSsgmm+8ZnjTCWmo8w48jLaSU+ZdsqVxnGPa41r+uWNqjTXQTiDqYU
IV90dHQh98OS2vtYZ/EM6+z7pljCZnY=
/

