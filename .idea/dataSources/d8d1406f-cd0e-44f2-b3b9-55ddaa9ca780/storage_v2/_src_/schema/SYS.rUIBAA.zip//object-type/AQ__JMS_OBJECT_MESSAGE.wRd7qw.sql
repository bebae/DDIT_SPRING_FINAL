create type aq$_jms_object_message
                                       wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
85 b2
nSPuK2M/z61nPWgB4JXWaz3oCIMwg5n0dLhcWlbD9HKXYkpyrpfyLtH0ci5i0dxZrlyPwHQr
pb+bwDLL7iWPCWmluDL1UrIJpvvGZ40wlpqPMOPIy2klPmXbKlcZxj2uNa/rljao010E4g6m
FCFfdHR0IffDktr7WGfxDOvs+6Zq7mZ+
/

