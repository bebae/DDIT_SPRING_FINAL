create type AWRBL_DETAILS_TYPE
  as object (dbid                number
            ,baseline_id         number
            ,instance_number     number
            ,start_snap_id       number
            ,start_snap_time     timestamp(3)
            ,end_snap_id         number
            ,end_snap_time       timestamp(3)
            ,shutdown            varchar2(3)
            ,error_count         number
            ,pct_total_time      number)
/

