create TYPE DBMS_XA_XID as OBJECT (
  FORMATID NUMBER,
  GTRID RAW(64),
  BQUAL RAW(64),
  constructor function DBMS_XA_XID(GTRID in NUMBER)
    return self as result,
  constructor function DBMS_XA_XID(GTRID in RAW, BQUAL in RAW)
    return self as result,
  constructor function DBMS_XA_XID(
      FORMATID in NUMBER,
      GTRID in RAW,
      BQUAL in RAW default HEXTORAW('00000000000000000000000000000001'))
    return self as result
)
/

