create TYPE dmbao AS OBJECT (
  t_seq_id         VARCHAR2(4000),
  pct_identity     NUMBER,
  alignment_length INTEGER,
  positives        INTEGER,
  mismatches       INTEGER,
  gap_openings     INTEGER,
  gap_list         dmbgos,
  q_seq_start      INTEGER,
  q_seq_end        INTEGER,
  q_frame          INTEGER,
  t_seq_start      INTEGER,
  t_seq_end        INTEGER,
  t_frame          INTEGER,
  score            INTEGER,
  expect           NUMBER
)
/

