create TYPE dmbco AS OBJECT (
  t_seq_id VARCHAR2(4000),
  t_seq_data BLOB
)
/

