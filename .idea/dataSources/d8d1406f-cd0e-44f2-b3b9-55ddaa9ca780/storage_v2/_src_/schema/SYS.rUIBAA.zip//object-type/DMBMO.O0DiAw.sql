create TYPE dmbmo AS OBJECT (
  t_seq_id VARCHAR2(4000),
  score    INTEGER,
  expect   NUMBER
)
/

