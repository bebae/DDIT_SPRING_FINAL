create TYPE dmglmbo wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
24b fb
zDJxftSu47MZb5FX557TZ5j7rWYwgwJyNZmsfATUCOIFsDDQntpHeaez3pfKalZhPjDwDgwl
/p2NVKiBSu3GmvmlfCRusnHGBRA0emfaV41bXkJaEYxbC72oeb9W8GNHQs32wR4YyIcFJ2Q7
WhSuPh4y61gBzqxfVsWVOncu0eHRHeL5dqnCn4ep/hBABUKmC/QDFa3GQvBOOcHhwWL/iAea
E0+dtdfgN+NEZW9NVMgH1vXEI+FHw/XE
/

