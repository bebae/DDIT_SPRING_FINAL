create TYPE DMMODBO wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
73 96
y6sTWY3Wldvm+mSDIRaPjIxUMp0wg+mX2supyi9GOPbcf2Mbh+GRC3zdq59i2DP5xMjbsYlO
qiO5RlSext2l4cv9Yhiz+3OMfvBdhcUwH21VNVoqPVyL0OUoWD+9SBny5aQA+uVF3lOmP852
Fw==
/

