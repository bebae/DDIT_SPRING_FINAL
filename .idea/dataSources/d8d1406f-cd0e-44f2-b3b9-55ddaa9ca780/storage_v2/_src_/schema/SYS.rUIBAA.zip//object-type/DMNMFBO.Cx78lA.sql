create TYPE dmnmfbo wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
a8 b2
u9hibzBlMWAbI6NJ+57Xxp0rmNcwg3n6f57hNXRgOB6t6fJElvcxc433WKLCWBXFyuDEuXPa
NelhtOoAzuSfRACLseQ0ltu23rxwuINJZtJrp/NW+4IqkhvtAbR/ENEYarRtl6ITP+ESeOQy
zS6Ad7j/Ms0ndjta907Q5nqknyBdgxb/

