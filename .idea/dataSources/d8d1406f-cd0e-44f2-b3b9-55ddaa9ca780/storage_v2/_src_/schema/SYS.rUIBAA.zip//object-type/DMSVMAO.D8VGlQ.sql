create TYPE dmsvmao wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
64 92
QJZma3H6tX5Bib5x3JA7IamT800wg5n0dLhcWvpi0dkuR+q4dCulv5vAMsvMUI8JaaX1zKnW
fMbKFyjGyu+yhO+ZLqQOkUsDqsjVwyWWd7H6KucUqy9du119XSmGiNO9lEMloMmmpjSvH9M=

/

