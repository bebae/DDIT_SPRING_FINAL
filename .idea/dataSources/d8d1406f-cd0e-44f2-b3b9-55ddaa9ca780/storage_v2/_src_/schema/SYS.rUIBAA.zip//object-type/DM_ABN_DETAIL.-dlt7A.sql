create type dm_abn_detail as object
  (rule_id               integer
  ,antecedent            dm_predicates
  ,consequent            dm_predicates
  ,rule_support          number)
/

