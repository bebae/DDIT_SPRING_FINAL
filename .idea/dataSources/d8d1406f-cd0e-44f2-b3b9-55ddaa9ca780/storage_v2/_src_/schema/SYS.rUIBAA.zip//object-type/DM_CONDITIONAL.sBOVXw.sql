create type dm_conditional as object
  (attribute_name        varchar2(4000)
  ,attribute_subname     varchar2(4000)
  ,attribute_str_value   varchar2(4000)
  ,attribute_num_value   number
  ,conditional_probability number)
/

