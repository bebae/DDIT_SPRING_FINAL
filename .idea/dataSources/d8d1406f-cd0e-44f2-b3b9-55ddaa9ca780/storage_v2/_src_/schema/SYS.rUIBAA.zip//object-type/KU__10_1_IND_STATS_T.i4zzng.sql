create type ku$_10_1_ind_stats_t as object
(
  vers_major        char(1),                          /* UDT major version # */
  vers_minor        char(1),                          /* UDT minor version # */
  obj_num           number,                                   /* Index obj # */
  base_obj_num      number,                                   /* Table obj # */
  base_tab_obj      ku$_schemaobj_t,
  base_ind_obj      ku$_schemaobj_t,
  type_num          number,                   /* what kind of index is this? */
  property          number,         /* immutable flags for life of the index */
  cols              number,
  rowcnt            number,
  leafcnt           number,
  distkey           number,
  lblkkey           number,
  dblkkey           number,
  clufac            number,
  blevel            number,
  ind_flags         number,
  obj_flags         number,
  cache_info        ku$_cached_stats_t, -- cached stats information
  partition_list    ku$_10_1_pind_stats_list_t,
  cnst_col_list     ku$_tab_col_list_t
)
/

