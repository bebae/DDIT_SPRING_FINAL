create type ku$_10_1_tab_ptab_stats_t as object
(
  obj_num           number,             -- table object number
  trigflag          number,             -- table trigflag
  schema_obj        ku$_schemaobj_t,    -- table schema object
  bobj_num          number,             -- base object number for part. tabs
  sysgen_cols       number,             -- system generated columns?
  blkcnt            number,             -- block count
  rowcnt            number,             -- row count
  avgrln            number,             -- average row length
  flags             number,             -- global/user spec. stats
  cache_info        ku$_cached_stats_t, -- cached stats information
  col_stats         ku$_10_1_col_stats_list_t
                                        -- column stats list for table (part)
)
/

