create type ku$_10_2_strmcoltype_t as object
(
  obj_num       number,                               /* obj# of base object */
  col_num       number,                                     /* column number */
  intcol_num    number,                            /* internal column number */
  owner_name    varchar2(30),                                  /* owner name */
  name          varchar2(30),                                 /* object name */
  flags         number,                                             /* flags */
                     /* flags to indicate whether column type is ADT, Array, */
                                                      /* REF or Nested table */
                           /* 0x02 - adt column                              */
                           /* 0x04 - nested table column                     */
                           /* 0x08 - varray column                           */
                           /* 0x10 - ref column                              */
                           /* 0x20 - retrieve collection out-of-line         */
                           /* 0x20 - don't strip the null image              */
                           /* 0x40 - don't chop null image                   */
                           /* 0x40 - collection storage specified            */
                           /* 0x80 - column stores an old (8.0) format image */
                          /* 0x100 - data for this column not yet upgraded   */
                          /* 0x200 - ADT column is substitutable             */
                          /* 0x400 - NOT SUBSTITUTABLE specified explicitly  */
                          /* 0x800 - SUBSTITUTABLE specified explicitly      */
                         /* 0x1000 - implicitly not substitutable            */
                         /* 0x2000 - The typeid column stores the toid       */
                         /* 0x4000 - The column is an opaque type column     */
                         /* 0x8000 - nested table name is system generated   */
  /* opqflags not present in 10g */
  toid          raw(16),                                             /* toid */
  version       number,                      /* internal type version number */
  hashcode      raw(17),                                 /* Version hashcode */
  typidcol_num  number,           /* intcol# of the type discriminant column */
  subtype_list  ku$_strmsubcoltype_list_t                /* subtype metadata */
)
/

