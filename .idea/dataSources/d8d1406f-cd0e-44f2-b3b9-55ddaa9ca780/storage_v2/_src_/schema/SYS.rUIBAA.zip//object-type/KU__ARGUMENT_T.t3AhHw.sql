create type ku$_argument_t as object
(
  obj_num        number,                                    /* object number */
  procedure_val  varchar2(30),       /* procedure name (if within a package) */
  overload_num   number,
                /* 0 - not overloaded, n - unique id of overloaded procedure */
  procedure_num  number,                       /* procedure or method number */
  position_num   number,           /* argument position (0 for return value) */
  sequence_num   number,
  level_num      number,
  argument       varchar2(30),      /* argument name (null for return value) */
  type_num       number,                                    /* argument type */
  charsetid      number,                                 /* character set id */
  charsetform    number,                               /* character set form */
  /* 1 = implicit: for CHAR, VARCHAR2, CLOB w/o a specified set */
  /* 2 = nchar: for NCHAR, NCHAR VARYING, NCLOB */
  /* 3 = explicit: for CHAR, etc. with "CHARACTER SET ..." clause */
  /* 4 = flexible: for PL/SQL "flexible" parameters */
  default_num    number,   /* null - no default value, 1 - has default value */
  in_out         number,                   /* null - IN, 1 - OUT, 2 - IN/OUT */
  properties     number,                           /* argument's properties: */
  /* 0x0100 =     256 = IN parameter (pass by value, default) */
  /* 0x0200 =     512 = OUT parameter */
  /* 0x0400 =    1024 = pass by reference parameter */
  /* 0x0800 =    2048 = required parameter (no default) */
  /* 0x4000 =   16384 = is a PONTER parameter */
  /* 0x8000 =   32768 = is a REF parameter */
  length         number,                                      /* data length */
  precision_num  number,                                /* numeric precision */
  scale          number,                                    /* numeric scale */
  radix          number,                                    /* numeric radix */
  deflength      number,             /* default value expression text length */
  default_val    varchar2(4000),            /* default value expression text */
--  default$       long,                      /* default value expression text */
  type_owner     varchar2(30),          /* owner name component of type name */
  type_name      varchar2(30),                                  /* type name */
  type_subname   varchar2(30),             /* subname component of type name */
  type_linkname  varchar2(30),             /* db link component of type name */
  pls_type       varchar2(30)                            /* pl/sql type name */
)
/

