create type ku$_audit_default_t as object
(
  vers_major       char(1),
  vers_minor       char(1),
  obj_num          number,                                /* object number */
  audit_val        varchar2(38),                       /* auditing options */
  aud_default_list sys.ku$_audit_default_list_t              /* audit list */
)
/

