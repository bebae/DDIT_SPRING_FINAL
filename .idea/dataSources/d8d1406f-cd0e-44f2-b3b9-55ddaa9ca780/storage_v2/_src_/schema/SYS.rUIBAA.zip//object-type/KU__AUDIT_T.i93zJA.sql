create type ku$_audit_t as object
(
  vers_major    char(1),
  vers_minor    char(1),
  user_num      number,                            /* user identifier number */
  user_name     varchar2(30),                                   /* user name */
  proxy_num     number,                             /* UID of the proxy user */
  audit_option  varchar2(40),                             /* auditing option */
  property      number,                   /* 0x01 = do not export this audit */
  success       number,                                 /* audit on success? */
  failure       number,                                 /* audit on failure? */
  option_num    number                              /* option# in option map */
)
/

