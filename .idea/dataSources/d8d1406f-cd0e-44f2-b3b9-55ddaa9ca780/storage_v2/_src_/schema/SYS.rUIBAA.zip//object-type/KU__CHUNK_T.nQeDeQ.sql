create TYPE     ku$_chunk_t AS OBJECT
(
  text  varchar2(4000),
  length        number
)
/

