create type ku$_cluster_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  obj_num       number,                                  /* cluster object # */
  schema_obj    ku$_schemaobj_t,                       /* cluster schema obj */
  col_list      ku$_column_list_t,
  ts_name       varchar2(30),                                  /* tablespace */
  blocksize     number,                            /* size of block in bytes */
  tsno          number,                                 /* tablespace number */
  fileno        number,                        /* segment header file number */
  blockno       number,                       /* segment header block number */
  pct_free      number,          /* minimum free space percentage in a block */
  pct_used      number,          /* minimum used space percentage in a block */
  initrans      number,                     /* initial number of transaction */
  maxtrans      number,                     /* maximum number of transaction */
  size_t        number,
  hashfunc      varchar2(30),              /* if hashed, function identifier */
  hashkeys      number,                                    /* hash key count */
  function      number, /* function: 0 (key is function), 1 (system default) */
  extind        number,             /* extent index value of fixed hash area */
  flags         number,                                      /* 0x08 = CACHE */
                                          /* 0x010000 = Single Table Cluster */
                                                /* 0x00800000 = DEPENDENCIES */
  degree        number,      /* number of parallel query slaves per instance */
  instances     number,       /*  number of OPS instances for parallel query */
  avgchn        number,          /* average chain length - previously spare4 */
  funclen       number,
  functxt       varchar2(4000),
  func_vcnt     ku$_vcnt,
  func_clob     clob,
  storage       ku$_storage_t,
  spare1        number,
  spare2        number,
  spare3        number,
  spare4        number,
  spare5        varchar2(1000),
  spare6        varchar2(1000),
  spare7        varchar2(19)
)
/

