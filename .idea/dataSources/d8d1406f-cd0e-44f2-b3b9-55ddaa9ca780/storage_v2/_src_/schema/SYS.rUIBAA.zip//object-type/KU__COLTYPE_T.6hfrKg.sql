create type ku$_coltype_t as object
(
  obj_num       number,                               /* obj# of base object */
  col_num       number,                                     /* column number */
  intcol_num    number,                            /* internal column number */
  flags         number,                                             /* flags */
  toid          raw(16),                                             /* toid */
  version       number,                      /* internal type version number */
  packed        number,                          /* 0 = unpacked, 1 = packed */
  intcols       number,                        /* number of internal columns */
                                          /* storing the exploded ADT column */
  intcol_nums   raw(2000),            /* list of intcol#s of columns storing */
                          /* the unpacked ADT column; stored in packed form; */
                                          /* each intcol# is stored as a ub2 */
  hashcode      raw(17),                                 /* Version hashcode */
  has_tstz      char(1),        /* 'Y' = this is a varray with TSTZ elements */
  typidcol_num  number,           /* intcol# of the type discriminant column */
  synobj_num    number,              /* obj# of type synonym of the col type */
  syn_name      varchar2(30),                       /* type synonym (if any) */
  syn_owner     varchar2(30),                               /* synonym owner */
  subtype_list  ku$_subcoltype_list_t,                   /* subtype metadata */
  schema_obj    ku$_schemaobj_t                             /* schema object */
)
/

