create type ku$_column_t as object
(
  obj_num       number,                      /* object number of base object */
  col_num       number,                          /* column number as created */
  segcol_num    number,                          /* column number in segment */
  segcollength  number,                      /* length of the segment column */
  offset        number,                                  /* offset of column */
  name          varchar2(30),                              /* name of column */
  attrname      varchar2(4000),/* name of type attr. column: null if != type */
  fullattrname  varchar2(4000),      /* expanded attrname for DTYNAR columns */
  type_num      number,                               /* data type of column */
  length        number,                         /* length of column in bytes */
  fixedstorage  number,             /* flags: 0x01 = fixed, 0x02 = read-only */
  precision_num number,                                         /* precision */
  scale         number,                                             /* scale */
  not_null      number,                               /* 0 = nulls permitted */
                                                 /* > 0 = no NULLs permitted */
  deflength     number,                   /* default value expr. text length */
  default_val   varchar2(4000),             /* default value expression text */
  parsed_def    sys.xmltype,                    /* parsed default expression */
  binarydefval  varchar2(4000),          /* default replace null with clause */
  intcol_num    number,                            /* internal column number */
  base_intcol_num number,    /* internal column number of base column, i.e., */
                           /* the intcol# of the first column with this col# */
  base_col_type number, /* base column type: 1 = UDT, 2 = XMLType OR or CSX, */
                        /*                   3 = XMLType as CLOB,  0 = other */
  base_col_name varchar2(30),      /* for any xmltype, name of xmltype column*/
  property      number,                     /* column properties (bit flags) */
  charsetid     number,                              /* NLS character set id */
  charsetform   number,
  con           ku$_constraint0_t,                    /* not null constraint */
  typemd        ku$_coltype_t,     /* type metadata. null if not a typed col */
  lobmd         ku$_lob_t,            /* lob metadata. null if not a lob col */
  opqmd         ku$_opqtype_t,   /* opaque metadata. null if not type opaque */
  oidindex      ku$_oidindex_t,   /*oidindex if col is OID$ col of obj table */
  spare1        number,                      /* fractional seconds precision */
  spare2        number,                  /* interval leading field precision */
  spare3        number,
  spare4        varchar2(1000),          /* NLS settings for this expression */
  spare5        varchar2(1000),
  spare6        varchar2(19)
)
/

