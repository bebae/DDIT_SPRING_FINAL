create type ku$_col_stats_t as object
(
  obj_num           number,             -- table/partition/subpartition objnum
  intcol_num        number,             -- internal column number
  distcnt           number,             -- distinct count
  lowval            raw(32),            -- low value
  hival             raw(32),            -- high value
  density           number,             -- density
  null_cnt          number,             -- null count
  avgcln            number,             -- average column length
  cflags            number,             -- flags
  eav               number,
  sample_size       number,
  minimum           number,
  maximum           number,
  spare1            number,             -- sample number of distinct values
  hist_gram_list    ku$_histgrm_list_t  -- histogram list
)
/

