create type ku$_constraint0_t as object
(
  owner_num     number,                                      /* owner user # */
  name          varchar2(30),                             /* constraint name */
  con_num       number,                                 /* constraint number */
  obj_num       number,                  /* object number of base table/view */
  numcols       number,                   /* number of columns in constraint */
  contype       number,                                   /* constraint type */
  enabled       number,           /* is constraint enabled? NULL if disabled */
  intcols       number,              /* #  of internal columns in constraint */
  mtime         varchar2(19),  /* date this constraint was last enabled-disabled */
  flags         number                                              /* flags */
)
/

