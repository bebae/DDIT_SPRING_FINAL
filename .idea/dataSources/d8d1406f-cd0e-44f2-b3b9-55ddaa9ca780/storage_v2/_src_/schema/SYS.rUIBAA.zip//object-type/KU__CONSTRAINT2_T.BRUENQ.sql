create type ku$_constraint2_t as object
(
  owner_num     number,                                      /* owner user # */
  name          varchar2(30),                             /* constraint name */
  con_num       number,                                 /* constraint number */
  obj_num       number,                  /* object number of base table/view */
  numcols       number,                   /* number of columns in constraint */
  contype       number,                                   /* constraint type */
  robj_num      number,                 /* object number of referenced table */
  rcon_num      number,                 /* constraint# of referenced columns */
  rrules        varchar2(3),                 /* future: use this for pendant */
  match_num     number,                 /* referential constraint match type */
  refact        number,                                /* referential action */
  enabled       number,           /* is constraint enabled? NULL if disabled */
  intcols       number,              /* #  of internal columns in constraint */
  mtime         varchar2(19), /* date this constraint was last enabled-disabled */
  flags         number,                                             /* flags */
  schema_obj    ku$_schemaobj_t,                  /* referenced table object */
  src_col_list  ku$_constraint_col_list_t,                 /* source columns */
  tgt_col_list  ku$_constraint_col_list_t                  /* target columns */
)
/

