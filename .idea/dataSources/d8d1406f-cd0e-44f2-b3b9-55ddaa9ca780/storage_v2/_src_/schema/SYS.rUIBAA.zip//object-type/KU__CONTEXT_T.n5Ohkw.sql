create type ku$_context_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  obj_num       number,                            /* context object number */
  schema_obj    ku$_schemaobj_t,                   /* context schema object */
  schema_name   varchar2(30),                                 /* schema name */
  package_name  varchar2(30),                                /* package name */
  flags         number
)
/

