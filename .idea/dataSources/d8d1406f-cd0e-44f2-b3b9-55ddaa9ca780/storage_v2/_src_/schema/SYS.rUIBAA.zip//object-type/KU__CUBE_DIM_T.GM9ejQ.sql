create type ku$_cube_dim_t as object
(
  obj_num       number,                             /* Parent table object # */
  colname       varchar2(100),                           /* Base data column */
  obj           varchar2(100),                           /* Mapped AW object */
  dimusing      varchar2(100),                    /* USING rel for native dt */
  gid           ku$_cube_fact_list_t,                                 /* GID */
  pgid          ku$_cube_fact_list_t,                          /* Parent GID */
  attrs         ku$_cube_fact_list_t,                          /* Attributes */
  levels        ku$_cube_fact_list_t,                              /* Levels */
  hiers         ku$_cube_hier_list_t,                         /* Hierarchies */
  flags         number                                              /* Flags */
)
/

