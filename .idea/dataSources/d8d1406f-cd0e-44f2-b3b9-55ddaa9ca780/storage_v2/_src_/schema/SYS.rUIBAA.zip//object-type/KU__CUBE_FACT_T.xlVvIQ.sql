create type ku$_cube_fact_t as object
(
  obj_num number,                                   /* Parent table object # */
  colname varchar2(100),                                  /* SQL column name */
  pcolname varchar2(100),                          /* Parent SQL column name */
  ccolname varchar2(100),                           /* COUNT SQL column name */
  obj     varchar2(100),                                 /* Mapped AW object */
  qdr     varchar2(100),                          /* QDRing dimension object */
  qdrval  varchar2(100),                                      /* QDRed value */
  flags   number                                                    /* Flags */
)
/

