create type ku$_dimension_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  obj_num       number,                           /* dimension object number */
  schema_obj    ku$_schemaobj_t,                  /* dimension schema object */
  dimtextlen    number,                                 /* length of dimtext */
  dimtext       clob                      /* store the dimension when length */
)
/

