create type ku$_dummy_factor_t as object
(
  vers_major           char(1),                      /* UDT major version # */
  vers_minor           char(1),                      /* UDT minor version # */
  factor_name          varchar2(30)                          /* Factor name */
)
/

