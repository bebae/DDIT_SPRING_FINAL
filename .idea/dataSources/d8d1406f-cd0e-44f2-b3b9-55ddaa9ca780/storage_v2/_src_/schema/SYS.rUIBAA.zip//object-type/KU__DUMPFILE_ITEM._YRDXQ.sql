create TYPE     ku$_dumpfile_item IS OBJECT
        (
                item_code       NUMBER,           -- Identifies header item
                value           VARCHAR2(2048)    -- Text string value
        )
/

