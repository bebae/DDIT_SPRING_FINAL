create TYPE     ku$_ErrorLine AS OBJECT
        (       errorNumber     NUMBER,
                errorText       VARCHAR2(2000) )
/

