create type ku$_exttab_t as object
(
  obj_num       number,                          /* base table object number */
  default_dir   varchar2(30),                           /* default directory */
  type          varchar2(30),                          /* access driver type */
  nr_locations  number,                               /* number of locations */
  reject_limit  number,                                      /* reject limit */
  par_type      number,             /* access parameter type: blob=1, clob=2 */
  param_clob    clob,                      /* access parameters in clob form */
  location      ku$_extloc_list_t                      /* external locations */
)
/

