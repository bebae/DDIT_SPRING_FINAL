create type ku$_histgrm_t as object
(
  obj_num           number,             -- histogram object number
  intcol_num        number,             -- internal object number
  bucket            number,             -- bucket information
  endpoint          number,             -- endpoint value
  epvalue           VARCHAR2(4000),     -- ep value
  spare1            number              -- sample number of distinct values
)
/

