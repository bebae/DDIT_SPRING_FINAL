create type ku$_indextype_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(2),                              /* UDT minor version # */
  obj_num       number,                                 /* obj# of indextype */
  schema_obj    ku$_schemaobj_t,                    /* base schema obj. info */
  impl_obj      ku$_schemaobj_t,        /* sch. info for implementation type */
  property      number,                                         /* property */
                                              /* 0x0001 WITHOUT_COLUMN_DATA */
                                                   /* 0x0002 WITH_ARRAY_DML */
                                              /* 0x0004 WITH_REBUILD_ONLINE */
                                                     /* 0x0008 HAS_ORDER_BY */
                                       /* 0x0010 WITH LOCAL_RANGE_PARTITION */
                                        /* 0x0020 WITH LOCAL_HASH_PARTITION */
                                                      /* 0x0040 WITHOUT_DML */
                                              /* 0x0080 AUTHID_CURRENT_USER */
  operators     ku$_indexop_list_t,
  indarray      ku$_indarraytype_list_t
)
/

