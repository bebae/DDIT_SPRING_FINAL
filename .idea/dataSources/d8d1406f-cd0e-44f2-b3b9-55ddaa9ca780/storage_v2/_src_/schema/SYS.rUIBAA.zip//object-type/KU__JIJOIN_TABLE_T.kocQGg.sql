create type ku$_jijoin_table_t as object
(
  obj_num       number,                                          /* object # */
  tabobj_num    number,                                  /* table obj number */
  owner_name    varchar2(30),                                 /* table owner */
  name          varchar2(30)                                 /* table name  */
)
/

