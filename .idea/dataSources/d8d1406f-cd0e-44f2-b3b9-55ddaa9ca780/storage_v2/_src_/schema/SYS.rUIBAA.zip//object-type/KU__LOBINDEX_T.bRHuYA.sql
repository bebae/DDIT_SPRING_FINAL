create type ku$_lobindex_t as object
(
  obj_num       number,                                          /* object # */
  schema_obj    ku$_schemaobj_t,                            /* schema object */
  ts_name       varchar2(30),                                  /* tablespace */
  blocksize     number,                            /* size of block in bytes */
  storage       ku$_storage_t,                                    /* storage */
  deferred_stg  ku$_deferred_stg_t,                      /* deferred storage */
  dataobj_num   number,                          /* data layer object number */
  cols          number,                                 /* number of columns */
  pct_free      number,          /* minimum free space percentage in a block */
  initrans      number,                     /* initial number of transaction */
  maxtrans      number,                    /* maximum number of transactions */
  pct_thres     number,           /* iot overflow threshold, null if not iot */
  type_num      number,                       /* what kind of index is this? */
  flags         number,                                     /* mutable flags */
  property      number,             /* immutable flags for life of the index */
  blevel        number,                                       /* btree level */
  leafcnt       number,                                  /* # of leaf blocks */
  distkey       number,                                   /* # distinct keys */
  lblkkey       number,                          /* avg # of leaf blocks/key */
  dblkkey       number,                          /* avg # of data blocks/key */
  clufac        number,                                 /* clustering factor */
  analyzetime   varchar2(19),                        /* timestamp when last analyzed */
  samplesize    number,                 /* number of rows sampled by Analyze */
  rowcnt        number,                       /* number of rows in the index */
  intcols       number,                        /* number of internal columns */
  degree        number,           /* # of parallel query slaves per instance */
  instances     number,             /* # of OPS instances for parallel query */
  trunccnt      number,                        /* re-used for iots 'inclcol' */
  numcolsdep    number,         /* number of columns depended on, >= intcols */
  numkeycols    number,             /* # of key columns in compressed prefix */
  spare3        number,
  spare4        varchar2(1000),     /* used for parameter str for domain idx */
  spare5        varchar2(1000),
  spare6        varchar2(19)
)
/

