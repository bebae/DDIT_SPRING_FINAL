create TYPE     ku$_multi_ddl AS OBJECT
        (       object_row      NUMBER,         -- object row of object
                ddls            sys.ku$_ddls    -- 1-N DDLs for the object
        )
/

