create type ku$_m_view_log_t as object
(
  vers_major      char(1),                            /* UDT major version # */
  vers_minor      char(1),                            /* UDT minor version # */
  mowner          varchar2(30),                           /* owner of master */
  master          varchar2(30),                            /* name of master */
  oldest          varchar2(19),  /* maximum age of rowid information in the log */
  oldest_pk       varchar2(21),  /* maximum age of PK information in the log */
  oscn            number,                                   /* scn of oldest */
  youngest        varchar2(21),             /* most recent snaptime assigned */
  yscn            number,                                      /* set-up scn */
  log             varchar2(30),                               /* name of log */
  trig            varchar2(30),                 /* trigger on master for log */
  flag            number,    /* 0x01, rowid         0x02, primary key values */
                             /* 0x04, column values 0x08, log is imported    */
                             /* 0x10, log is created with temp table         */
  mtime           varchar2(21),                     /* DDL modification time */
  temp_log        varchar2(30),      /* temp table as updatable snapshot log */
  oldest_oid      varchar2(21), /* maximum age of OID information in the log */
  oldest_new      varchar2(21),      /* maximum age of new values in the log */
  oldest_seq      varchar2(21), /* maximum age of sequence values in the log */
  global_db_name  varchar2(4000),                    /* Global database Name */
  purge_start     varchar2(21),                          /* purge start date */
  purge_next      varchar2(200),               /* purge next date expression */
  fc_count        number,                        /* number of filter columns */
  fc_list         ku$_refcol_list_t,                   /* filter column list */
  lm_count        number,                         /* number of local masters */
  lm_list         ku$_slog_list_t                       /* local master list */
)
/

