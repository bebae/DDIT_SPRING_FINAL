create type ku$_m_view_scm_t as object
(
  snacol            varchar2(30),                 /* name of snapshot column */
  mascol            varchar2(30),                      /* master column name */
  maspos            number,            /* position of master column (intcol) */
  colrole           number,                       /* how is this column used */
  snapos            integer             /* position of col in snapshot table */
)
/

