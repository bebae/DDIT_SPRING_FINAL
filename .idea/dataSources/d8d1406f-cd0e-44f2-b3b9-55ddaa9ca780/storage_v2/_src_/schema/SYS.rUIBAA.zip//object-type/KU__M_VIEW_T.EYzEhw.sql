create type ku$_m_view_t as object
(
  vers_major        char(1),                          /* UDT major version # */
  vers_minor        char(1),                          /* UDT minor version # */
  sowner            varchar2(30),                       /* Owner of snapshot */
  vname             varchar2(30),                        /* name of snapshot */
  tname             varchar2(30),                              /* Table name */
  mowner            varchar2(30),                         /* owner of master */
  master            varchar2(30),                          /* name of master */
  mlink             varchar2(128),           /* database link to master site */
  snapshot          varchar2(21), /* used by V7 masters to identify snapshot */
  snapid            integer,  /* used by V8 masters to identify the snapshot */
  auto_fast         varchar2(8),      /* date function for automatic refresh */
  auto_fun          varchar2(200),                  /* next time for refresh */
  auto_date         varchar2(19),                  /* start time for refresh */
  uslog             varchar2(30),             /* log for updatable snapshots */
  status            integer,                           /* refresh operations */
  master_version    integer,            /* Oracle version of the master site */
  tables            integer,                 /* Number of tables in snapshot */
  flag              number,
  flag2             number,
  flag3             number,
  lobmaskvec        raw(255),                     /* lob columns mask vector */
  mas_roll_seg      varchar2(30),            /* master-side rollback segment */
  rscn              number,                              /* last refresh scn */
  instsite          integer,                           /* instantiating site */
  flavor_id         number,                                     /* flavor id */
  objflag           number,                 /* object properties of snapshot */
  sna_type_owner    varchar2(30),                    /* object MV type owner */
  sna_type_name     varchar2(30),                     /* object MV type name */
  mas_type_owner    varchar2(30),          /* master object table type owner */
  mas_type_name     varchar2(30),           /* master object table type name */
  parent_sowner     varchar2(30),                   /* parent snapshot owner */
  parent_vname      varchar2(30),                    /* parent snapshot name */
  query_len         number,                                  /* query length */
  query_txt         clob,              /* query which this view instantiates */
  parsed_query_txt  sys.xmltype,                         /* parsed query_txt */
  query_vcnt        ku$_vcnt,          /* store the query when length > 4000 */
  rel_query         clob,              /* relational transformation of query */
  loc_roll_seg      varchar2(30),             /* local side rollback segment */
  global_db_name    varchar2(4000),                  /* Global database Name */
  syn_count         number,                /* Number of synonyms in snapshot */
  srt_list          ku$_m_view_srt_list_t
)
/

