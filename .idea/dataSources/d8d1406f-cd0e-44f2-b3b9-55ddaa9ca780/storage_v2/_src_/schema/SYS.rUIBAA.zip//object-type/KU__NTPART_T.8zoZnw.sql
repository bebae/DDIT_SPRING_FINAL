create type ku$_ntpart_t as object
(
  obj_num       number,                                /* obj# of base table */
  part_num      number,                               /* part# of base table */
  intcol_num    number,              /* internal column number in base table */
  ntab_num      number,              /* object number of nested table object */
  schema_obj    ku$_schemaobj_t,           /* schema object for nested table */
  col           ku$_simple_col_t,                                  /* column */
  property      number,                           /* nested table properties */
  flags         number,                                /* nested table flags */
  hnt           ku$_hntp_t                      /* heap table partition data */
)
/

