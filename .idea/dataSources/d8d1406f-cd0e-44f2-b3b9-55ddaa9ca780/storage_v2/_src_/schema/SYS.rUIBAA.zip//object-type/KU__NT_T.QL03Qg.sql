create type ku$_nt_t as object
(
  obj_num       number,                                /* obj# of base table */
  intcol_num    number,              /* internal column number in base table */
  ntab_num      number,              /* object number of nested table object */
  schema_obj    ku$_schemaobj_t,           /* schema object for nested table */
  col           ku$_simple_col_t,                                  /* column */
  property      number,                                  /* table properties */
  flags         number,                                             /* flags */
  hnt           ku$_hnt_t,                                /* heap table data */
  iont          ku$_iont_t,                                      /* iot data */
  col_list      ku$_column_list_t                         /* list of columns */
)
/

