create type ku$_objgrant_t as object
(
  vers_major    char(2),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  obj_num       number,                                 /* obj# of base obj. */
  base_obj      ku$_schemaobj_t,                           /* base obj. info */
  long_name     varchar2(4000),
  grantor       varchar2(30),
  grantee       varchar2(30),
  wgo           number,
  colname       varchar2(30),
  sequence      number,
  privs         ku$_privname_list_t)
/

