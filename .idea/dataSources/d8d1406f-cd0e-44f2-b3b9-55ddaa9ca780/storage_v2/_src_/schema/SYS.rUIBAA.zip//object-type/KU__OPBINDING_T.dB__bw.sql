create type ku$_opbinding_t as object
(
  obj_num       number,                            /* operator object number */
  bind_num      number,                            /* number of this binding */
  functionname  varchar2(92),                /* func that impl. this binding */
  returnschema  varchar2(30),              /* schema of return type (if ADT) */
  returntype    varchar2(30),                     /* return type of function */
  impschema     varchar2(30),             /* indextype implementation schema */
  imptype       varchar2(30),               /* indextype implementation type */
  property      number,                                    /* property flags */
  spare1        varchar2(30),
  spare2        varchar2(30),
  spare3        number,
  args          ku$_oparg_list_t,              /* arguments for this binding */
  ancillaries   ku$_opancillary_list_t  /* list of primary ops for this ancil*/
)
/

