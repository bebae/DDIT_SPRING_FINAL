create TYPE     ku$_ParamValue1010 IS OBJECT
        (
                param_name      VARCHAR2(30),           -- Parameter name
                param_op        VARCHAR2(30),           -- Param operation
                param_type      VARCHAR2(30),           -- Its type
                param_length    NUMBER,                 -- Its length in bytes
                param_value_n   NUMBER,                 -- Numeric value
                param_value_t   VARCHAR2(4000)          -- And its text value
        )
/

