create type ku$_pind_stats_t as object
(
  obj_num           number,
  partname          VARCHAR2(30),
  bobj_num          number,
  rowcnt            number,
  leafcnt           number,
  distkey           number,
  lblkkey           number,
  dblkkey           number,
  clufac            number,
  blevel            number,
  ind_flags         number,
  obj_flags         number,
  sample_size       number,
  analyzetime       varchar2(19),       -- timestamp when last analyzed
  cache_info        ku$_cached_stats_t, -- cached stats information
  subpartition_list ku$_spind_stats_list_t
)
/

