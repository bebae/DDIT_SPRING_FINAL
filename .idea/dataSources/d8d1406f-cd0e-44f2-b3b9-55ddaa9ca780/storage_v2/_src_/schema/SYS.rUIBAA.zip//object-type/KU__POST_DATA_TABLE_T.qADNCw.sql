create type ku$_post_data_table_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(2),                              /* UDT minor version # */
  obj_num       number,                                 /* obj# of base obj. */
  schema_obj    ku$_schemaobj_t,                           /* base obj. info */
  spare1        number   /* 32768 (0x8000) set if minimize records per block */
)
/

