create type ku$_procact_schema_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  user_name     varchar2(30),                                   /* user name */
  package       varchar2(30),                          /* procedural package */
  schema        varchar2(30),                            /* procedual schema */
  level_num     number,                                             /* level */
  class         number,                                             /* class */
  prepost       number,                         /* 0:preaction, 1:postaction */
  plsql         ku$_procobj_lines      /* PL/SQL code for procedural objects */
)
/

