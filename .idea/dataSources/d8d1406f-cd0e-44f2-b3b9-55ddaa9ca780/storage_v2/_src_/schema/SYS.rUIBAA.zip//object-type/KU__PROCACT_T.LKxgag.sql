create type ku$_procact_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  package       varchar2(30),                          /* procedural package */
  schema       varchar2(30),                              /* package schema */
  level_num     number,                                             /* level */
  class         number,                                             /* class */
  prepost       number,                         /* 0:preaction, 1:postaction */
  plsql         ku$_procobj_lines      /* PL/SQL code for procedural objects */
)
/

