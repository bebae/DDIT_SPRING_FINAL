create type ku$_procdepobja_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  obj_num       number,                                     /* object number */
  base_obj      ku$_schemaobj_t,                            /* base object */
  class         number,                                             /* class */
  prepost       number,                         /* 0:preaction, 1:postaction */
  type_num      number,                                              /* type */
  level_num     number,                                             /* level */
  package       varchar2(30),                                     /* package */
  pkg_schema    varchar2(30),                              /* package schema */
  anc_obj       ku$_schemaobj_t,                      /* ancestor schema obj */
  plsql         ku$_procobj_lines      /* PL/SQL code for procedural objects */
)
/

