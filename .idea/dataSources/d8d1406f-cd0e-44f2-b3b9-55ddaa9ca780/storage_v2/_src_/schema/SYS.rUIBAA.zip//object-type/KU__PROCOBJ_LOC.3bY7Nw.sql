create TYPE     ku$_procobj_loc AS OBJECT
        (       newblock        NUMBER,
                line_of_code    VARCHAR2(32767) )
/

