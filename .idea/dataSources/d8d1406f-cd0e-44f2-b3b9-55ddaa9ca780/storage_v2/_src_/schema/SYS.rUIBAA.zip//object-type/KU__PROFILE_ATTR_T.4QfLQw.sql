create type ku$_profile_attr_t as object
(
  profile_id    number,                                       /* profile id  */
  resource_num  number,                                        /* resource id*/
  resname       varchar2(30),                               /* resource name */
  type_num              number,                                      /* type */
  limit_num             number                                      /* limit */
)
/

