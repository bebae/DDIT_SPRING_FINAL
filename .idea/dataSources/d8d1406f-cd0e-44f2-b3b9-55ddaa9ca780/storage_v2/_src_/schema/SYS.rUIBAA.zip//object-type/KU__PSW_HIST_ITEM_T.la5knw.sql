create type ku$_psw_hist_item_t as object
(
  user_id       number,                    /* pws history user object number */
  uname         varchar2(30),                                   /* user name */
  password      varchar2(30),                                    /* password */
  password_date varchar2(19)                                   /* start date */
)
/

