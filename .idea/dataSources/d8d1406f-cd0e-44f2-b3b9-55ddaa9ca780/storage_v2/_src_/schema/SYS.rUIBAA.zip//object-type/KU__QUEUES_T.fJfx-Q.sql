create type ku$_queues_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  obj_num       number,                         /* queue table object number */
  qid           number,                            /* queue obj number */
  schema_obj    ku$_schemaobj_t,                      /* queue object schema */
  base_obj      ku$_schemaobj_t,                   /* queue table obj schema */
  tflags        number,                            /* queue table properties */
  usage         number,                                /* usage of the queue */
  max_retries   number,                         /* maximum number of retries */
  retry_delay   number,                      /* delay before retrying (secs) */
  enqueue_enabled number,                                 /*  queue enabled? */
  properties    number,                      /*  various properties of queue */
  retention     number,                       /* retention time (in seconds) */
  queue_comment  varchar2(2000)                              /* user comment */
)
/

