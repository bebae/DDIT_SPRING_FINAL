create type ku$_queue_table_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  obj_num       number,                         /* queue table object number */
  schema_obj    ku$_schemaobj_t,                    /* object of queue table */
  storage_clause ku$_qtab_storage_t,                  /* storage_clause info */
  udata_type    number,                                     /* userdata type */
  object_type   varchar2(61),                          /* userdata type name */
  sort_cols     number,                            /* sort order for dequeue */
  flags         number,                            /* queue table properties */
  table_comment         varchar2(2000),                      /* user comment */
  primary_instance      number,                /*  primary owner instance-id */
  secondary_instance    number,               /* secondary owner instance-id */
  owner_instance        number                  /* current owner instance-id */
)
/

