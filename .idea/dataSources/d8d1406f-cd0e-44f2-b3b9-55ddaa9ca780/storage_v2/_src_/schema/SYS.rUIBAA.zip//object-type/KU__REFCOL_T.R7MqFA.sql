create type ku$_refcol_t as object
(
  colname         varchar2(30),                  /* master table column name */
  oldest          varchar2(21),  /* maximum age of information in the column */
  flag            number                          /* column meta information */
)
/

