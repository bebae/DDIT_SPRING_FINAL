create type ku$_refgroup_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  refname       varchar2(30),                       /* name of refresh group */
  owner_num     number,                                 /* owner user number */
  refowner      varchar2(30),                      /* owner of refresh group */
  refgroup      number,                           /* number of refresh group */
  ref_make_user varchar2(2000),     /* executing string of dbms_refresh.make */
  ref_make_dba  varchar2(2000),    /* executing string of dbms_irefresh.make */
  ref_child     ku$_add_snap_list_t              /* refresh group child info */
                                          /* dbms_refresh.add execute string */
)
/

