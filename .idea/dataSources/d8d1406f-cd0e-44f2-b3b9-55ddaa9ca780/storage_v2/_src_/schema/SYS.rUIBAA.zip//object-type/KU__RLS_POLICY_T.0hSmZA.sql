create type ku$_rls_policy_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  base_obj      ku$_schemaobj_t,                       /* base schema object */
  obj_num       number,                              /* parent object number */
  gname         varchar2(30),                        /* name of policy group */
  name          varchar2(30),                              /* name of policy */
  stmt_type     number,                        /* applicable statement type: */
  check_opt     number,                                 /* with check option */
  enable_flag   number,                         /* 0 = disabled, 1 = enabled */
  pfschma       varchar2(30),                   /* schema of policy function */
  ppname        varchar2(30),                         /* policy package name */
  pfname        varchar2(30),                        /* policy function name */
  policy_type   varchar2(35),                                 /* policy type */
  long_pred     number,                           /* 32K long predicate size */
  rel_cols      ku$_rls_sec_rel_col_list_t,     /* security relevant columns */
  rel_cols_opt  number                   /* security relevant columns option */
)
/

