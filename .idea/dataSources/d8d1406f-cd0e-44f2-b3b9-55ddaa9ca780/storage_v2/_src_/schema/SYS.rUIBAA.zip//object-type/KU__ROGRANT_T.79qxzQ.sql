create type ku$_rogrant_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  grantee_id    number,                                         /* user id  */
  grantee       varchar2(30),                                    /* grantee */
  role          varchar2(30),                                       /* role */
  role_id       number,                                          /* role id */
  admin         number,                                    /*  admin option */
  sequence      number                             /* unique grant sequence */
)
/

