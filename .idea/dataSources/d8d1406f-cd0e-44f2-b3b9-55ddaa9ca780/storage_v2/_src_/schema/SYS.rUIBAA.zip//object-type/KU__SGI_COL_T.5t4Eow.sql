create type ku$_sgi_col_t as object
(
  obj_num           number,                 -- index object number
  con_num           number,                 -- constraint number if constraint
  name              varchar2(30)            -- column name
)
/

