create type ku$_sgr_sge_t as object
(
 obj_num        number,
 grantor_num    number,
 grantee_num    number,
 colnum         number,
 wgo            number,
 min_sequence   number);
/

