create type ku$_simple_type_t as object
(
  toid          raw(16),                                             /* toid */
  version_num   number,                                /* internal version # */
  version       varchar2(30),                         /* UDT minor version # */
  type_num      number,                      /* type encoding (see sqldef.h) */
  properties    number,                                   /* type properties */
  attribute_num number,                              /* number of attributes */
  local_attrs   number,                        /* number of local attributes */
  method_num    number,                                 /* number of methods */
  hidmethod_num number,                         /* number of hiddend methods */
  typeid        raw(16), /* short typeid value (for non final and sub types) */
  roottoid      raw(16),          /* TOID of root type (null if not subtype) */
  hashcode      raw(17),                                 /* Version hashcode */
  schema_obj    ku$_schemaobj_t,                            /* schema object */
  type_name     varchar2(30)                                    /* type name */
)
/

