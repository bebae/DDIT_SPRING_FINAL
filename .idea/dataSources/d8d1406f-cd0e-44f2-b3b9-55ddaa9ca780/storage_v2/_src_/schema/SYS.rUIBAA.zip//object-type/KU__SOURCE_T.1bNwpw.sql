create TYPE     ku$_source_t AS OBJECT
(
  obj_num       number,                                     /* object number */
  line          number,                                       /* line number */
  --
  -- The next 2 attributes are used by XSL scripts to edit the source line.
  -- E.g., in a type definition, the line might be 'type foobar as object' --
  -- 'foobar' is the object name.  Since the xsl script has already
  -- generated CREATE OR REPLACE TYPE FOOBAR, it uses 'post_name_off'
  -- to extract the useful part of the line.  If the source were
  -- create type /* this is a comment
  --  that continues on the next line */
  --  foobar
  -- which is rare but legal, the xsl script knows from 'pre_name' which
  -- lines are prior to the name and can safely be discarded.
  -- See bug 2844111 and rdbms/xml/xsl/kusource.xsl.
  pre_name      number,    /* 1 = this line is prior to line containing name */
  post_name_off number,   /* 1-based offset of 1st non-space char after name */
  post_keyw     number,   /* the offset of post keyword */
  pre_name_len  number,   /* length between keyword and name */
  --
  -- The next attribute is needed for appending the SQL terminator.
  -- If the last line ends in a newline, we simply add the "/";
  -- otherwise, we must insert a newline before the "/".
  -- This attribute is NULL for all but the last line; for the last
  -- line it is "Y" if the line ends in a newline, "N" otherwise.
  trailing_nl   char(1),
  source        varchar2(4000)                                /* source line */
)
/

