create PACKAGE dbms_aq_exp_dequeuelog_tables wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
1ec 13c
6nWAXoeHQP4TtB1VZmcT+Exr+7Qwg5DI7dwdNXRGJrs+cayi6ROXxB5oO8DBVbSYN//yiZQu
L6Ko09ByRKg/nmc4GPcTIHrsRkg3pK+fTrhLgRn82bd5HvlU0DL+MCByHtfiHKYMudZb6qLj
A5Rs+3fo+3Ufn62iQN3s96STj0IhRQy4+lfTNNWlkdWOsYxocXilCneBIQYk3RSJUYuufLJ7
lJd39+SVOYFiP3kSOZhms+vnFx/JRQ2f40h/VS1dIK5kGVRrcUYk4RckNt/bHM/a5e6boLxC
o2/FIdv/ZWEdKYoGlBpQEYU=
/

