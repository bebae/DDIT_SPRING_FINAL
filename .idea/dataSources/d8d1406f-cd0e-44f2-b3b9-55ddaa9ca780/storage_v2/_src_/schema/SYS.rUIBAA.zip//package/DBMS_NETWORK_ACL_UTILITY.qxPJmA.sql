create package dbms_network_acl_utility is

  /*
   * DBMS_NETWORK_ACL_UTILITY is the PL/SQL package that provides the utility
   * functions to facilitate the evaluation of ACL assignments governing
   * TCP connections to network hosts.
   */

  -----------
  -- Types --
  -----------
  type domain_table is table of varchar2(1000);

  /*
   * For a given host, return the domains whose ACL assigned will be used to
   * determine if a user has the privilege to access the given host or not.
   * When the IP address of the host is given, return the subnets instead.
   *
   * PARAMETERS
   *   host       the network host.
   * RETURN
   *   The domains or subnets for the given host.
   * EXCEPTIONS
   *
   * NOTES
   *   This function cannot handle IPv6 addresses. Nor can it generate
   *   subnets of arbitrary number of prefix bits for an IPv4 address.
   */
  function domains(host in varchar2) return domain_table pipelined;

  /*
   * Return the domain level of the given host name, domain, or subnet.
   *
   * PARAMETERS
   *   host       the network host, domain, or subnet.
   * RETURN
   *   The domain level of the given host, domain, or subnet.
   * EXCEPTIONS
   *
   * NOTES
   *   This function cannot handle IPv6 addresses and subnets, and subnets
   *   in Classless Inter-Domain Routing (CIDR) notation.
   */
  function domain_level(host in varchar2) return number;

  /*
   * Determines if the two given hosts, domains, or subnets are equal. For
   * IP addresses and subnets, this function can handle different
   * representations of the same address or subnet. For example, an IPv6
   * representation of an IPv4 address versus its IPv4 representation.
   *
   * PARAMETERS
   *   host1      the network host, domain, or subnet to compare.
   *   host2      the network host, domain, or subnet to compare.
   * RETURN
   *   1 if the two hosts, domains, or subnets are equal. 0 when not equal.
   *   NULL when either of the hosts is NULL.
   * EXCEPTIONS
   *
   * NOTES
   *   This function does not perform domain name resolution when comparing
   * any host or domain for equality.
   */
  function equals_host(host1 in varchar2, host2 in varchar2) return number;
    pragma interface(C, equals_host);

  /*
   * Determines if the given host is equal to or contained in the given host,
   * domain, or subnet. For IP addresses and subnets, this function can handle
   * different representations of the same address or subnet. For example, an
   * IPv6 representation of an IPv4 address versus its IPv4 representation.
   *
   * PARAMETERS
   *   host       the network host.
   *   domain     the host, domain, or subnet.
   * RETURN
   *   A non-NULL value will be returned if the given host is equal to or
   *   contained in the given host, domain, or subnet:
   *     - if domain is a hostname, the level of its domain + 1 will be
   *       returned;
   *     - if domain is a domain name, the domain level will be returned;
   *     - if domain is an IP address or subnet, the number of significant
   *       address bits of the IP address or subnet will be returned;
   *     - if domain is the wildcard "*", 0 will be returned.
   *   The non-NULL value returned indicates the precedence of the domain or
   *   subnet for ACL assignment. The higher the value, the higher is the
   *   precedence. NULL will be returned if the host is not equal to or
   *   contained in the given host, domain or subnet. NULL will also be
   *   returned if either the host or domain is NULL.
   * EXCEPTIONS
   *
   * NOTES
   *   This function does not perform domain name resolution when evaluating
   * any host or domain.
   */
  function contains_host(host in varchar2, domain in varchar2) return number;
    pragma interface(C, contains_host);

end;
/

