create PACKAGE dbms_reputil2 AS

  ------------
  --  OVERVIEW
  --
  --  This package is referenced only by the generated code
  --  and needs higher purity than the code in dbms_reputil.

  FUNCTION bit(flag       IN RAW,
               byte       IN NUMBER,
               bit_offset IN NUMBER) RETURN BOOLEAN;
  PRAGMA RESTRICT_REFERENCES(bit, WNPS, RNDS, WNDS);
  -- Test a bit in a byte in a raw.  Byte and bit_offset are 1-based.

  FUNCTION bit(flag       IN RAW,
               bit_offset IN NUMBER) RETURN BOOLEAN;
  PRAGMA RESTRICT_REFERENCES(bit, WNPS, RNDS, WNDS);
  -- Test a bit in a raw. Bit_offset is 1-based.

  -- same 2 functions above but returns number for use in SQL
  -- changed args ordering in order to override. SQL cannot choose between
  -- return boolean and return number
  FUNCTION bit(byte       IN NUMBER,
               bit_offset IN NUMBER,
               flag       IN RAW) RETURN NUMBER;
  PRAGMA RESTRICT_REFERENCES(bit, WNPS, RNDS, WNDS);
  -- Test a bit in a byte in a raw.  Byte and bit_offset are 1-based.

  FUNCTION bit(bit_offset IN NUMBER,
               flag       IN RAW) RETURN NUMBER;
  PRAGMA RESTRICT_REFERENCES(bit, WNPS, RNDS, WNDS);
  -- Test a bit in a raw. Bit_offset is 1-based.

  PROCEDURE bis(flag       IN OUT RAW,
                bit_offset IN     NUMBER);
  PRAGMA RESTRICT_REFERENCES(bis, WNPS, RNDS, WNDS);
  -- Set a bit in a one-byte raw.  Bit_offset is 1-based.

  PROCEDURE bic(flag       IN OUT RAW,
                bit_offset IN     NUMBER);
  PRAGMA RESTRICT_REFERENCES(bic, WNPS, RNDS, WNDS);
  -- Clear a bit in a one-byte raw.  Bit_offset is 1-based.

  FUNCTION choose_number(old  IN NUMBER,
                         new  IN NUMBER,
                         flag IN VARCHAR2,
                         byte IN NUMBER) RETURN NUMBER;
  -- If flag is null or substr(flag,byte,1) = 'Y' then return new
  -- else return old.
  PRAGMA RESTRICT_REFERENCES(choose_number, WNPS, RNDS, WNDS);

  FUNCTION choose_date(old  IN DATE,
                       new  IN DATE,
                       flag IN VARCHAR2,
                       byte IN NUMBER) RETURN DATE;
  -- If flag is null or substr(flag,byte,1) = 'Y' then return new
  -- else return old.
  PRAGMA RESTRICT_REFERENCES(choose_date, WNPS, RNDS, WNDS);

  FUNCTION choose_varchar2(old  IN VARCHAR2,
                           new  IN VARCHAR2,
                           flag IN VARCHAR2,
                           byte IN NUMBER) RETURN VARCHAR2;
  -- If flag is null or substr(flag,byte,1) = 'Y' then return new
  -- else return old.
  PRAGMA RESTRICT_REFERENCES(choose_varchar2, WNPS, RNDS, WNDS);

  FUNCTION choose_nvarchar2(old  IN NVARCHAR2,
                            new  IN NVARCHAR2,
                            flag IN VARCHAR2,
                            byte IN NUMBER) RETURN NVARCHAR2;
  -- If flag is null or substr(flag,byte,1) = 'Y' then return new
  -- else return old.
  PRAGMA RESTRICT_REFERENCES(choose_nvarchar2, WNPS, RNDS, WNDS);

  FUNCTION choose_char(old  IN CHAR,
                       new  IN CHAR,
                       flag IN VARCHAR2,
                       byte IN NUMBER) RETURN CHAR;
  -- If flag is null or substr(flag,byte,1) = 'Y' then return new
  -- else return old.
  PRAGMA RESTRICT_REFERENCES(choose_char, WNPS, RNDS, WNDS);

  FUNCTION choose_nchar(old  IN NCHAR,
                        new  IN NCHAR,
                        flag IN VARCHAR2,
                        byte IN NUMBER) RETURN NCHAR;
  -- If flag is null or substr(flag,byte,1) = 'Y' then return new
  -- else return old.
  PRAGMA RESTRICT_REFERENCES(choose_nchar, WNPS, RNDS, WNDS);

  FUNCTION choose_rowid(old  IN ROWID,
                        new  IN ROWID,
                        flag IN VARCHAR2,
                        byte IN NUMBER) RETURN ROWID;
  -- If flag is null or substr(flag,byte,1) = 'Y' then return new
  -- else return old.
  PRAGMA RESTRICT_REFERENCES(choose_rowid, WNPS, RNDS, WNDS);

  FUNCTION choose_raw(old  IN RAW,
                      new  IN RAW,
                      flag IN VARCHAR2,
                      byte IN NUMBER) RETURN RAW;
  -- If flag is null or substr(flag,byte,1) = 'Y' then return new
  -- else return old.
  PRAGMA RESTRICT_REFERENCES(choose_raw, WNPS, RNDS, WNDS);

  FUNCTION choose_blob(old  IN BLOB,
                       new  IN BLOB,
                       flag IN VARCHAR2,
                       byte IN NUMBER) RETURN BLOB;
  -- If flag is null or substr(flag,byte,1) = 'Y' then return new
  -- else return old.
  PRAGMA RESTRICT_REFERENCES(choose_blob, RNPS, WNPS, RNDS, WNDS);

  FUNCTION choose_clob(old  IN CLOB,
                       new  IN CLOB,
                       flag IN VARCHAR2,
                       byte IN NUMBER) RETURN CLOB;
  -- If flag is null or substr(flag,byte,1) = 'Y' then return new
  -- else return old.
  PRAGMA RESTRICT_REFERENCES(choose_clob, RNPS, WNPS, RNDS, WNDS);

  FUNCTION choose_nclob(old  IN NCLOB,
                        new  IN NCLOB,
                        flag IN VARCHAR2,
                        byte IN NUMBER) RETURN NCLOB;
  -- If flag is null or substr(flag,byte,1) = 'Y' then return new
  -- else return old.
  PRAGMA RESTRICT_REFERENCES(choose_nclob, RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_varchar2_equals_new(column_changed$_varchar2 IN VARCHAR2,
                                   offset                   IN NUMBER,
                                   old                      IN VARCHAR2
                                                               CHARACTER SET
                                                               ANY_CS,
                                   new                      IN VARCHAR2
                                                               CHARACTER SET
                                                               old%CHARSET)
    RETURN VARCHAR2;
  -- If old and new are identical then return 'Y' else return 'N.'
  -- Use column_changed$_varchar2 if not null.
  -- Otherwise use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_varchar2_equals_new, RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_char_equals_new(column_changed$_varchar2 IN VARCHAR2,
                               offset                   IN NUMBER,
                               old                      IN CHAR CHARACTER SET
                                                           ANY_CS,
                               new                      IN CHAR CHARACTER SET
                                                           old%CHARSET)
    RETURN VARCHAR2;
  -- If old and new are identical then return 'Y' else return 'N.'
  -- Use column_changed$_varchar2 if not null.
  -- Otherwise use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_char_equals_new, RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_rowid_equals_new(column_changed$_varchar2 IN VARCHAR2,
                                offset                IN NUMBER,
                                old                   IN ROWID,
                                new                   IN ROWID)
    RETURN VARCHAR2;
  -- If old and new are identical then return 'Y' else return 'N.'
  -- Use column_changed$_varchar2 if not null.
  -- Otherwise use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_rowid_equals_new, RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_date_equals_new(column_changed$_varchar2 IN VARCHAR2,
                               offset                   IN NUMBER,
                               old                      IN DATE,
                               new                      IN DATE)
    RETURN VARCHAR2;
  -- If old and new are identical then return 'Y' else return 'N.'
  -- Use column_changed$_varchar2 if not null.
  -- Otherwise use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_date_equals_new, RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_raw_equals_new(column_changed$_varchar2 IN VARCHAR2,
                              offset                   IN NUMBER,
                              old                      IN RAW,
                              new                      IN RAW)
    RETURN VARCHAR2;
  -- If old and new are identical then return 'Y' else return 'N.'
  -- Use column_changed$_varchar2 if not null.
  -- Otherwise use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_raw_equals_new, RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_number_equals_new(column_changed$_varchar2 IN VARCHAR2,
                                 offset                   IN NUMBER,
                                 old                      IN NUMBER,
                                 new                      IN NUMBER)
    RETURN VARCHAR2;
  -- If old and new are identical then return 'Y' else return 'N.'
  -- Use column_changed$_varchar2 if not null.
  -- Otherwise use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_number_equals_new, RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_clob_equals_new(column_changed$_varchar2 IN VARCHAR2,
                               offset                   IN NUMBER,
                               old                      IN CLOB CHARACTER SET
                                                           ANY_CS,
                               new                      IN CLOB CHARACTER SET
                                                           old%CHARSET)
    RETURN VARCHAR2;
  -- If old and new are identical then return 'Y' else return 'N.'
  -- Use column_changed$_varchar2 if not null.
  -- Otherwise use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_clob_equals_new, RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_blob_equals_new(column_changed$_varchar2 IN VARCHAR2,
                               offset                   IN NUMBER,
                               old                      IN BLOB,
                               new                      IN BLOB)
    RETURN VARCHAR2;
  -- If old and new are identical then return 'Y' else return 'N.'
  -- Use column_changed$_varchar2 if not null.
  -- Otherwise use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_blob_equals_new, RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_varchar2_eq_new(column_changed$_varchar2 IN VARCHAR2,
                               offset                   IN NUMBER,
                               old                      IN VARCHAR2
                                                           CHARACTER SET
                                                           ANY_CS,
                               new                      IN VARCHAR2
                                                           CHARACTER SET
                                                           old%CHARSET)
    RETURN BOOLEAN;
  -- If old and new are identical then return true else return false.
  -- Use column_changed$_varchar2 if not null.
  -- Otherwise use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_varchar2_eq_new, RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_char_eq_new(column_changed$_varchar2 IN VARCHAR2,
                           offset                   IN NUMBER,
                           old                      IN CHAR CHARACTER SET
                                                       ANY_CS,
                           new                      IN CHAR CHARACTER SET
                                                       old%CHARSET)
    RETURN BOOLEAN;
  -- If old and new are identical then return true else return false.
  -- Use column_changed$_varchar2 if not null.
  -- Otherwise use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_char_eq_new, RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_date_eq_new(column_changed$_varchar2 IN VARCHAR2,
                           offset                   IN NUMBER,
                           old                      IN DATE,
                           new                      IN DATE)
    RETURN BOOLEAN;
  -- If old and new are identical then return true else return false.
  -- Use column_changed$_varchar2 if not null.
  -- Otherwise use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_date_eq_new, RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_rowid_eq_new(column_changed$_varchar2 IN VARCHAR2,
                            offset                   IN NUMBER,
                            old                      IN ROWID,
                            new                      IN ROWID)
    RETURN BOOLEAN;
  -- If old and new are identical then return true else return false.
  -- Use column_changed$_varchar2 if not null.
  -- Otherwise use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_rowid_eq_new, RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_raw_eq_new(column_changed$_varchar2 IN VARCHAR2,
                          offset                   IN NUMBER,
                          old                      IN RAW,
                          new                      IN RAW)
    RETURN BOOLEAN;
  -- If old and new are identical then return true else return false.
  -- Use column_changed$_varchar2 if not null.
  -- Otherwise use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_raw_eq_new, RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_number_eq_new(column_changed$_varchar2 IN VARCHAR2,
                             offset                   IN NUMBER,
                             old                      IN NUMBER,
                             new                      IN NUMBER)
    RETURN BOOLEAN;
  -- If old and new are identical then return true else return false.
  -- Use column_changed$_varchar2 if not null.
  -- Otherwise use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_number_eq_new, RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_clob_eq_new(column_changed$_varchar2 IN VARCHAR2,
                           offset                   IN NUMBER,
                           old                      IN CLOB CHARACTER SET
                                                       ANY_CS,
                           new                      IN CLOB CHARACTER SET
                                                       old%CHARSET)
    RETURN BOOLEAN;
  -- If old and new are identical then return true else return false.
  -- Use column_changed$_varchar2 if not null.
  -- Otherwise use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_clob_eq_new, RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_blob_eq_new(column_changed$_varchar2 IN VARCHAR2,
                           offset                   IN NUMBER,
                           old                      IN BLOB,
                           new                      IN BLOB)
    RETURN BOOLEAN;
  -- If old and new are identical then return true else return false.
  -- Use column_changed$_varchar2 if not null.
  -- Otherwise use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_blob_eq_new, RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_varchar2_equals_current(column_sent$_varchar2 IN VARCHAR2,
                                       offset                IN NUMBER,
                                       old                   IN VARCHAR2
                                                                CHARACTER SET
                                                                ANY_CS,
                                       current               IN VARCHAR2
                                                                CHARACTER SET
                                                                old%CHARSET)
    RETURN VARCHAR2;
  -- If column_sent$_varchar2 is NULL, return 'Y.'
  -- If old and current are identical then return 'Y' else return 'N.'
  -- Use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_varchar2_equals_current,
                             RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_char_equals_current(column_sent$_varchar2 IN VARCHAR2,
                                   offset                IN NUMBER,
                                   old                   IN CHAR CHARACTER SET
                                                            ANY_CS,
                                   current               IN CHAR CHARACTER SET
                                                            old%CHARSET)
    RETURN VARCHAR2;
  -- If column_sent$_varchar2 is NULL, return 'Y.'
  -- If old and current are identical then return 'Y' else return 'N.'
  -- Use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_char_equals_current,
                             RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_raw_equals_current(column_sent$_varchar2 IN VARCHAR2,
                                  offset                IN NUMBER,
                                  old                   IN RAW,
                                  current               IN RAW)
    RETURN VARCHAR2;
  -- If column_sent$_varchar2 is NULL, return 'Y.'
  -- If old and current are identical then return 'Y' else return 'N.'
  -- Use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_raw_equals_current,
                             RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_rowid_equals_current(column_sent$_varchar2 IN VARCHAR2,
                                    offset                IN NUMBER,
                                    old                   IN ROWID,
                                    current               IN ROWID)
    RETURN VARCHAR2;
  -- If column_sent$_varchar2 is NULL, return 'Y.'
  -- If old and current are identical then return 'Y' else return 'N.'
  -- Use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_rowid_equals_current,
                             RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_date_equals_current(column_sent$_varchar2 IN VARCHAR2,
                                   offset                IN NUMBER,
                                   old                   IN DATE,
                                   current               IN DATE)
    RETURN VARCHAR2;
  -- If column_sent$_varchar2 is NULL, return 'Y.'
  -- If old and current are identical then return 'Y' else return 'N.'
  -- Use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_date_equals_current,
                             RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_number_equals_current(column_sent$_varchar2 IN VARCHAR2,
                                     offset                IN NUMBER,
                                     old                   IN NUMBER,
                                     current               IN NUMBER)
    RETURN VARCHAR2;
  -- If column_sent$_varchar2 is NULL, return 'Y.'
  -- If old and current are identical then return 'Y' else return 'N.'
  -- Use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_number_equals_current,
                             RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_blob_equals_current(column_sent$_varchar2 IN VARCHAR2,
                                   offset                IN NUMBER,
                                   old                   IN BLOB,
                                   current               IN BLOB)
    RETURN VARCHAR2;
  -- If column_sent$_varchar2 is NULL, return 'Y.'
  -- If old and current are identical then return 'Y' else return 'N.'
  -- Use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_blob_equals_current,
                             RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_clob_equals_current(column_sent$_varchar2 IN VARCHAR2,
                                   offset                IN NUMBER,
                                   old                   IN CLOB CHARACTER SET
                                                            ANY_CS,
                                   current               IN CLOB CHARACTER SET
                                                            old%CHARSET)
    RETURN VARCHAR2;
  -- If column_sent$_varchar2 is NULL, return 'Y.'
  -- If old and current are identical then return 'Y' else return 'N.'
  -- Use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_clob_equals_current,
                             RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_varchar2_eq_current(column_sent$_varchar2 IN VARCHAR2,
                                   offset                IN NUMBER,
                                   old                   IN VARCHAR2
                                                            CHARACTER SET
                                                            ANY_CS,
                                   current               IN VARCHAR2
                                                            CHARACTER SET
                                                            old%CHARSET)
    RETURN BOOLEAN;
  -- If column_sent$_varchar2 is NULL, return 'Y.'
  -- If old and current are identical then return 'Y' else return 'N.'
  -- Use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_varchar2_eq_current,
                             RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_char_eq_current(column_sent$_varchar2 IN VARCHAR2,
                               offset                IN NUMBER,
                               old                   IN CHAR CHARACTER SET
                                                        ANY_CS,
                               current               IN CHAR CHARACTER SET
                                                        old%CHARSET)
    RETURN BOOLEAN;
  -- If column_sent$_varchar2 is NULL, return 'Y.'
  -- If old and current are identical then return 'Y' else return 'N.'
  -- Use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_char_eq_current,
                             RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_raw_eq_current(column_sent$_varchar2 IN VARCHAR2,
                              offset                IN NUMBER,
                              old                   IN RAW,
                              current               IN RAW)
    RETURN BOOLEAN;
  -- If column_sent$_varchar2 is NULL, return 'Y.'
  -- If old and current are identical then return 'Y' else return 'N.'
  -- Use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_raw_eq_current,
                             RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_rowid_eq_current(column_sent$_varchar2 IN VARCHAR2,
                                offset                IN NUMBER,
                                old                   IN ROWID,
                                current               IN ROWID)
    RETURN BOOLEAN;
  -- If column_sent$_varchar2 is NULL, return 'Y.'
  -- If old and current are identical then return 'Y' else return 'N.'
  -- Use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_rowid_eq_current,
                             RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_date_eq_current(column_sent$_varchar2 IN VARCHAR2,
                               offset                IN NUMBER,
                               old                   IN DATE,
                               current               IN DATE)
    RETURN BOOLEAN;
  -- If column_sent$_varchar2 is NULL, return 'Y.'
  -- If old and current are identical then return 'Y' else return 'N.'
  -- Use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_date_eq_current,
                             RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_number_eq_current(column_sent$_varchar2 IN VARCHAR2,
                                 offset                IN NUMBER,
                                 old                   IN NUMBER,
                                 current               IN NUMBER)
    RETURN BOOLEAN;
  -- If column_sent$_varchar2 is NULL, return 'Y.'
  -- If old and current are identical then return 'Y' else return 'N.'
  -- Use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_number_eq_current,
                             RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_clob_eq_current(column_sent$_varchar2 IN VARCHAR2,
                               offset                IN NUMBER,
                               old                   IN CLOB CHARACTER SET
                                                        ANY_CS,
                               current               IN CLOB CHARACTER SET
                                                        old%CHARSET)
    RETURN BOOLEAN;
  -- If column_sent$_varchar2 is NULL, return 'Y.'
  -- If old and current are identical then return 'Y' else return 'N.'
  -- Use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_clob_eq_current,
                             RNPS, WNPS, RNDS, WNDS);

  FUNCTION old_blob_eq_current(column_sent$_varchar2 IN VARCHAR2,
                               offset                IN NUMBER,
                               old                   IN BLOB,
                               current               IN BLOB)
    RETURN BOOLEAN;
  -- If column_sent$_varchar2 is NULL, return 'Y.'
  -- If old and current are identical then return 'Y' else return 'N.'
  -- Use equality and null checks.
  PRAGMA RESTRICT_REFERENCES(old_blob_eq_current,
                             RNPS, WNPS, RNDS, WNDS);

  FUNCTION get_final_varchar2(column_changed$_varchar2 IN VARCHAR2,
                              offset                   IN NUMBER,
                              current                  IN VARCHAR2 CHARACTER
                                                          SET ANY_CS,
                              old                      IN VARCHAR2
                                                          CHARACTER SET
                                                          "CURRENT"%CHARSET,
                              new                      IN VARCHAR2
                                                          CHARACTER SET
                                                          "CURRENT"%CHARSET)
    RETURN VARCHAR2 CHARACTER SET "CURRENT"%CHARSET;
  -- If old and new are identical, then return current else return new.
  -- Use column_changed$_varchar2 if non-null.
  PRAGMA RESTRICT_REFERENCES(get_final_varchar2, RNPS, WNPS, RNDS, WNDS);

  FUNCTION get_final_char(column_changed$_varchar2 IN VARCHAR2,
                          offset                   IN NUMBER,
                          current                  IN CHAR CHARACTER SET
                                                      ANY_CS,
                          old                      IN CHAR CHARACTER SET
                                                      "CURRENT"%CHARSET,
                          new                      IN CHAR CHARACTER SET
                                                      "CURRENT"%CHARSET)
    RETURN CHAR CHARACTER SET "CURRENT"%CHARSET;
  -- If old and new are identical, then return current else return new.
  -- Use column_changed$_varchar2 if non-null.
  PRAGMA RESTRICT_REFERENCES(get_final_char, RNPS, WNPS, RNDS, WNDS);

  FUNCTION get_final_rowid(column_changed$_varchar2 IN VARCHAR2,
                           offset                   IN NUMBER,
                           current                  IN ROWID,
                           old                      IN ROWID,
                           new                      IN ROWID)
    RETURN ROWID;
  -- If old and new are identical, then return current else return new.
  -- Use column_changed$_varchar2 if non-null.
  PRAGMA RESTRICT_REFERENCES(get_final_rowid, RNPS, WNPS, RNDS, WNDS);

  FUNCTION get_final_date(column_changed$_varchar2 IN VARCHAR2,
                          offset                   IN NUMBER,
                          current                  IN DATE,
                          old                      IN DATE,
                          new                      IN DATE)
    RETURN DATE;
  -- If old and new are identical, then return current else return new.
  -- Use column_changed$_varchar2 if non-null.
  PRAGMA RESTRICT_REFERENCES(get_final_date, RNPS, WNPS, RNDS, WNDS);

  FUNCTION get_final_raw(column_changed$_varchar2 IN VARCHAR2,
                         offset                   IN NUMBER,
                         current                  IN RAW,
                         old                      IN RAW,
                         new                      IN RAW)
    RETURN RAW;
  -- If old and new are identical, then return current else return new.
  -- Use column_changed$_varchar2 if non-null.
  PRAGMA RESTRICT_REFERENCES(get_final_raw, RNPS, WNPS, RNDS, WNDS);

  FUNCTION get_final_number(column_changed$_varchar2 IN VARCHAR2,
                            offset                   IN NUMBER,
                            current                  IN NUMBER,
                            old                      IN NUMBER,
                            new                      IN NUMBER)
    RETURN NUMBER;
  -- If old and new are identical, then return current else return new.
  -- Use column_changed$_varchar2 if non-null.
  PRAGMA RESTRICT_REFERENCES(get_final_number, RNPS, WNPS, RNDS, WNDS);

  FUNCTION get_final_lob(column_changed$_char     IN CHAR,
                         current                  IN CLOB CHARACTER SET
                                                     ANY_CS,
                         new                      IN CLOB CHARACTER SET
                                                     "CURRENT"%CHARSET)
    RETURN CLOB CHARACTER SET "CURRENT"%CHARSET;
  -- column_changed$_char is non NULL
  -- returns new if and only if column_changed$_char is 'Y'
  PRAGMA RESTRICT_REFERENCES(get_final_lob, RNPS, WNPS, RNDS, WNDS);

  FUNCTION get_final_lob(column_changed$_char     IN CHAR,
                         current                  IN BLOB,
                         new                      IN BLOB)
    RETURN BLOB;
  -- column_changed$_char is non NULL
  -- returns new if and only if column_changed$_char is 'Y'
  PRAGMA RESTRICT_REFERENCES(get_final_lob, RNPS, WNPS, RNDS, WNDS);

  FUNCTION get_final_clob(column_changed$_varchar2 IN VARCHAR2,
                          offset                   IN NUMBER,
                          current                  IN CLOB CHARACTER SET
                                                      ANY_CS,
                          old                      IN CLOB CHARACTER SET
                                                      "CURRENT"%CHARSET,
                          new                      IN CLOB CHARACTER SET
                                                      "CURRENT"%CHARSET)
    RETURN CLOB CHARACTER SET "CURRENT"%CHARSET;
  -- If old and new are identical, then return current else return new.
  -- Use column_changed$_varchar2 if non-null.
  PRAGMA RESTRICT_REFERENCES(get_final_clob, RNPS, WNPS, RNDS, WNDS);

  FUNCTION get_final_blob(column_changed$_varchar2 IN VARCHAR2,
                          offset                   IN NUMBER,
                          current                  IN BLOB,
                          old                      IN BLOB,
                          new                      IN BLOB)
    RETURN BLOB;
  -- If old and new are identical, then return current else return new.
  -- Use column_changed$_varchar2 if non-null.
  PRAGMA RESTRICT_REFERENCES(get_final_blob, RNPS, WNPS, RNDS, WNDS);

END dbms_reputil2;
/

