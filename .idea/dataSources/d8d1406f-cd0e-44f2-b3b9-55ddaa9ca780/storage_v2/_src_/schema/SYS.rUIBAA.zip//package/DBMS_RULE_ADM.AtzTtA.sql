create PACKAGE dbms_rule_adm AUTHID CURRENT_USER AS

  --------------------
  --  PUBLIC CONSTANT
  --
  -- privilege code for rule engine objects

  -- system privileges
  CREATE_EVALUATION_CONTEXT_OBJ     CONSTANT BINARY_INTEGER := 1;
  CREATE_ANY_EVALUATION_CONTEXT     CONSTANT BINARY_INTEGER := 2;
  ALTER_ANY_EVALUATION_CONTEXT      CONSTANT BINARY_INTEGER := 3;
  DROP_ANY_EVALUATION_CONTEXT       CONSTANT BINARY_INTEGER := 4;
  EXECUTE_ANY_EVALUATION_CONTEXT    CONSTANT BINARY_INTEGER := 5;

  CREATE_RULE_SET_OBJ               CONSTANT BINARY_INTEGER := 6;
  CREATE_ANY_RULE_SET               CONSTANT BINARY_INTEGER := 7;
  ALTER_ANY_RULE_SET                CONSTANT BINARY_INTEGER := 8;
  DROP_ANY_RULE_SET                 CONSTANT BINARY_INTEGER := 9;
  EXECUTE_ANY_RULE_SET              CONSTANT BINARY_INTEGER := 10;

  CREATE_RULE_OBJ                   CONSTANT BINARY_INTEGER := 11;
  CREATE_ANY_RULE                   CONSTANT BINARY_INTEGER := 12;
  ALTER_ANY_RULE                    CONSTANT BINARY_INTEGER := 13;
  DROP_ANY_RULE                     CONSTANT BINARY_INTEGER := 14;
  EXECUTE_ANY_RULE                  CONSTANT BINARY_INTEGER := 15;

  -- object privileges
  EXECUTE_ON_EVALUATION_CONTEXT     CONSTANT BINARY_INTEGER := 16;
  ALTER_ON_EVALUATION_CONTEXT       CONSTANT BINARY_INTEGER := 17;
  ALL_ON_EVALUATION_CONTEXT         CONSTANT BINARY_INTEGER := 18;

  EXECUTE_ON_RULE_SET               CONSTANT BINARY_INTEGER := 19;
  ALTER_ON_RULE_SET                 CONSTANT BINARY_INTEGER := 20;
  ALL_ON_RULE_SET                   CONSTANT BINARY_INTEGER := 21;

  EXECUTE_ON_RULE                   CONSTANT BINARY_INTEGER := 22;
  ALTER_ON_RULE                     CONSTANT BINARY_INTEGER := 23;
  ALL_ON_RULE                       CONSTANT BINARY_INTEGER := 24;

  -- return codes for evaluation_function associated with an evaluation
  -- context
  -- These codes are interpreted as follows:
  -- EVALUATION_SUCCESS: evaluation completed successfully
  -- EVALUATION_FAILURE: evaluation failed due to errors
  -- EVALUATION_CONTINUE: continue default evaluation of the rule set

  EVALUATION_SUCCESS                CONSTANT BINARY_INTEGER := 0;
  EVALUATION_FAILURE                CONSTANT BINARY_INTEGER := 1;
  EVALUATION_CONTINUE               CONSTANT BINARY_INTEGER := 2;

  -- named exceptions
  INVALID_NV_NAME EXCEPTION;
    PRAGMA exception_init(INVALID_NV_NAME, -24161);

  PROCEDURE create_evaluation_context(
                evaluation_context_name IN varchar2,
                table_aliases           IN sys.re$table_alias_list := NULL,
                variable_types          IN sys.re$variable_type_list := NULL,
                evaluation_function     IN varchar2 := NULL,
                evaluation_context_comment IN varchar2 := NULL);

  PROCEDURE alter_evaluation_context(
                evaluation_context_name IN varchar2,
                table_aliases           IN sys.re$table_alias_list := NULL,
                remove_table_aliases    IN boolean := FALSE,
                variable_types          IN sys.re$variable_type_list := NULL,
                remove_variable_types   IN boolean := FALSE,
                evaluation_function     IN varchar2 := NULL,
                remove_evaluation_function  IN boolean := FALSE,
                evaluation_context_comment  IN varchar2 := NULL,
                remove_eval_context_comment IN boolean := FALSE);

  PROCEDURE drop_evaluation_context(
                evaluation_context_name IN varchar2,
                force                   IN boolean := FALSE);

  PROCEDURE create_rule_set(
                rule_set_name           IN varchar2,
                evaluation_context      IN varchar2 := NULL,
                rule_set_comment        IN varchar2 := NULL);

  PROCEDURE drop_rule_set(
                rule_set_name           IN varchar2,
                delete_rules            IN boolean := FALSE);

  PROCEDURE create_rule(
                rule_name               IN varchar2,
                condition               IN varchar2,
                evaluation_context      IN varchar2 := NULL,
                action_context          IN sys.re$nv_list := NULL,
                rule_comment            IN varchar2 := NULL);

  PROCEDURE alter_rule(
                rule_name                 IN varchar2,
                condition                 IN varchar2 := NULL,
                evaluation_context        IN varchar2 := NULL,
                remove_evaluation_context IN boolean := FALSE,
                action_context            IN sys.re$nv_list := NULL,
                remove_action_context     IN boolean := FALSE,
                rule_comment              IN varchar2 := NULL,
                remove_rule_comment       IN boolean := FALSE);

  PROCEDURE drop_rule(
                rule_name               IN varchar2,
                force                   IN boolean := FALSE);

  PROCEDURE add_rule(
                rule_name               IN varchar2,
                rule_set_name           IN varchar2,
                evaluation_context      IN varchar2 := NULL,
                rule_comment            IN varchar2 := NULL);

  PROCEDURE remove_rule(
                rule_name               IN varchar2,
                rule_set_name           IN varchar2,
                evaluation_context      IN varchar2 := NULL,
                all_evaluation_contexts IN boolean  := FALSE);

  PROCEDURE grant_system_privilege(
                privilege               IN binary_integer,
                grantee                 IN varchar2,
                grant_option            IN boolean := FALSE);

  PROCEDURE revoke_system_privilege(
                privilege               IN binary_integer,
                revokee                 IN varchar2);

  PROCEDURE grant_object_privilege(
                privilege               IN binary_integer,
                object_name             IN varchar2,
                grantee                 IN varchar2,
                grant_option            IN boolean := FALSE);

  PROCEDURE revoke_object_privilege(
                privilege               IN binary_integer,
                object_name             IN varchar2,
                revokee                 IN varchar2);

END dbms_rule_adm;
/

