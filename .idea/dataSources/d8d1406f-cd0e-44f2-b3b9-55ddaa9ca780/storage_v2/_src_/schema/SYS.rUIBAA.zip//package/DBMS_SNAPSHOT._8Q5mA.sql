create PACKAGE dbms_snapshot IS

  -- constants for snapshot version
  reg_unknown	      CONSTANT NUMBER := 0;
  reg_v7_snapshot     CONSTANT NUMBER := 1;
  reg_v8_snapshot     CONSTANT NUMBER := 2;
  reg_repapi_snapshot CONSTANT NUMBER := 3;

  -- constants for register_mview(), parameter 'flag'
  -- NOTE: keep these constants in sync with snap$.flag
  --       and dba_registered_mviews
  reg_rowid_mview            CONSTANT NUMBER := 16;
  reg_primary_key_mview      CONSTANT NUMBER := 32;
  reg_object_id_mview        CONSTANT NUMBER := 536870912;
  reg_fast_refreshable_mview CONSTANT NUMBER := 1;
  reg_updatable_mview        CONSTANT NUMBER := 2;

  ------------
  --  OVERVIEW
  --
  --  These routines allow the user to refresh snapshots and purge logs.

  ------------------------------------------------
  --  SUMMARY OF SERVICES PROVIDED BY THIS PACKAGE
  --
  --  refresh		         - refresh a given snapshot
  --  refresh_all	         - refresh all snapshots that are due
  --			           to be refreshed
  --  refresh_dependent          - refresh all stale snapshots that depend
  --                               on the specified master tables
  --  refresh_all_mviews         - refresh all stale snapshots
  --  get_mv_dependencies	 - gets the list of snapshots that depend
  --                               on the specified tables/snapshots.
  --  i_am_a_refresh             - return TRUE if local site is in the process
  --                               of refreshing one or more snapshots
  --  set_i_am_a_refresh         - set the refresh indicator
  --  begin_table_reorganization - indicate the start of a table reorganization
  --  end_table_reorganization   - indicate the end of a table reorganization
  --  purge_log		         - purge log of unnecessary rows
  --  purge_direct_load_log	 - purge direct loader log of unnecessary rows
  --  register_snapshot          - register a snapshot with the master site
  --  unregister_snapshot        - unregister a snapshot with the master site
  --  purge_snapshot_from_log    - purge the snapshot log for a specific
  --                               snapshot
  --  pmarker			 - partition marker generator
  --  explain_rewrite            - explain why a query failed to rewrite
  --  explain_mview              - explain an mv or potential mv
  --  estimate_mview_size        - estimate the size of a potential MV

  ----------------------------
  --  PROCEDURES AND FUNCTIONS
  --

  --  -----------------------------------------------------------------------
  --  Transaction consistent refresh of an array of snapshots.
  --  The max number of snapshots that can be consistently refreshed is 400.
  --  The snapshots are refreshed atomically and consistently.
  --  Atomically: all snapshots are refreshed or none are.
  --  Consistently: all integrity constraints that hold among master tables
  --                will hold among the snapshot tables.
  --
  --   LIST
  --     A comma-separated list or PL/SQL table of the snapshots
  --     to be refreshed.
  --   METHOD
  --     A string that contains a letter for each
  --     of the snapshots in the array according to the following codes:
  --     '?' -- use fast refresh when possible
  --     'F' -- use fast refresh or raise an error if not possible
  --     'C' -- perform a complete refresh, copying the entire snapshot from
  --            the master
  --     The default method for refreshing a snapshot is the method stored for
  --     that snapshot in the data dictionary.
  --   ROLLBACK_SEG
  --     The name of the rollback segment to use while
  --     refreshing snapshots.
  --   PUSH_DEFERRED_RPC
  --     If TRUE then push all changes made to an updatable snapshot to its
  --     associated master before refreshing the snapshot.  Otherwise, these
  --     changes may appear to be temporarily lost.
  --   REFRESH_AFTER_ERRORS
  --     If TRUE, then allow the refresh to proceed
  --     even if there are outstanding conflicts logged in the DefError
  --     table for the snapshot's master.
  --   PURGE_OPTION
  --     How to purge the transaction queue if PUSH_DEFERRED_RPC is true.
  --     0 = don't
  --     1 = cheap but imprecise (optimize for time)
  --     2 = expensive but precise (optimize for space)
  --   PARALLELISM
  --     Max degree of parallelism for pushing deferred RPCs. This value
  --     is considered only if PUSH_DEFERRED_RPC is true.
  --     0 = (old algorithm) serial propagation
  --     1 = (new algorithm) parallel propagation with only 1 slave
  --     n = (new algorithm) parallel propagation with n slaves
  --   HEAP_SIZE
  --     The max number of txns to be examined simultaneously for
  --     parallel scheduling computation. This parameter is used only if
  --     the value of the PARALLELISM parameter is greater than 0.
  --   ATOMIC_REFRESH
  --     If TRUE, then perform the refresh operations for the specified
  --     set of snapshots in a single transaction. This guarantees that either
  --     all of the snapshots are successfully refresh or none of the snapshots
  --     are refreshed.
  --   NESTED
  --     If TRUE, then perform nested refresh operations for the specified
  --     set of MVs. Nested refresh operations refresh all the depending MVs
  --     and the specified set of MVs based on a dependency order to ensure
  --     the MVs are truly fresh with respect to the underlying base tables.
  PROCEDURE refresh(list                 IN VARCHAR2,
                    method               IN VARCHAR2       := NULL,
                    rollback_seg         IN VARCHAR2       := NULL,
                    push_deferred_rpc    IN BOOLEAN        := TRUE,
                    refresh_after_errors IN BOOLEAN        := FALSE,
                    purge_option         IN BINARY_INTEGER := 1,
                    parallelism          IN BINARY_INTEGER := 0,
                    heap_size            IN BINARY_INTEGER := 0,
                    atomic_refresh       IN BOOLEAN        := TRUE,
                    nested               IN BOOLEAN        := FALSE);

  PROCEDURE refresh(tab                  IN OUT dbms_utility.uncl_array,
                    method               IN VARCHAR2       := NULL,
                    rollback_seg         IN VARCHAR2       := NULL,
                    push_deferred_rpc    IN BOOLEAN        := TRUE,
                    refresh_after_errors IN BOOLEAN        := FALSE,
                    purge_option         IN BINARY_INTEGER := 1,
                    parallelism          IN BINARY_INTEGER := 0,
                    heap_size            IN BINARY_INTEGER := 0,
                    atomic_refresh       IN BOOLEAN        := TRUE,
                    nested               IN BOOLEAN        := FALSE);

  --  -----------------------------------------------------------------------
  --  Execute all refresh jobs due to be executed
  --  Requires ALTER ANY SNAPSHOT privilege
  PROCEDURE refresh_all;

  --  -----------------------------------------------------------------------
  --  Refresh all local snapshots based on a specified local master table where
  --    1) the table has been modified since it was last successfully refreshed
  --    2) the snapshot is a member of dba_mview_analysis
  --  NOTE:
  --    A snapshot will be considered only if all of its tables are local.
  --
  --   NUMBER_OF_FAILURES
  --     Returns the number of failures that occurred during processing.
  --   LIST
  --     A comma-separated list of the master tables to consider.
  --   TAB
  --     A PL/SQL table of the master tables to consider.
  --   METHOD
  --     A string of refresh methods indicating how to refresh the dependent
  --     snapshots.  All of the snapshots that depend on a particular table
  --     are refreshed according to the refresh method associated with that
  --     table.  If a table does not have a corresponding refresh method
  --     (that is, more tables are specified than refresh methods), then any
  --     snapshot that depends on that table is refreshed according to its
  --     default refresh method.  The default refresh method for a snapshot
  --     is stored in the data dictionary.
  --     The refresh methods are represented by the following codes:
  --     '?' -- use fast refresh if possible;  otherwise, use complete refresh
  --     'F' -- use fast refresh if possible;  otherwise, raise an error
  --     'C' -- use complete refresh to construct the entire snapshot from
  --            the master tables
  --   ROLLBACK_SEG
  --     The name of the rollback segment to use while refreshing the snapshots.
  --   REFRESH_AFTER_ERRORS
  --     If TRUE and if ATOMIC_REFRESH is FALSE, then an error will not be
  --     raised if an error is encountered during the refresh.  Otherwise,
  --     any error encountered during refresh will be raised.
  --   ATOMIC_REFRESH
  --     If TRUE, then refresh all of the dependent snapshots in a single
  --     transaction.  This guarantees that either all of the snapshots are
  --     successfully refreshed or none of the snapshots are refreshed.
  --     Otherwise, refresh each dependent snapshot in a separate transaction.
  --   NESTED
  --     If TRUE, then perform nested refresh operations for the specified
  --     set of tables. Nested refresh operations refresh all the depending MVs
  --     of the specified set of tables based on a dependency order to ensure
  --     the MVs are truly fresh with respect to the underlying base tables.
  PROCEDURE refresh_dependent(number_of_failures   OUT BINARY_INTEGER,
                              list                  IN VARCHAR2,
                              method                IN VARCHAR2 := NULL,
                              rollback_seg          IN VARCHAR2 := NULL,
                              refresh_after_errors  IN BOOLEAN  := FALSE,
                              atomic_refresh        IN BOOLEAN  := TRUE,
                              nested                IN BOOLEAN  := FALSE);

  PROCEDURE refresh_dependent(number_of_failures   OUT BINARY_INTEGER,
                              tab                   IN dbms_utility.uncl_array,
                              method                IN VARCHAR2 := NULL,
                              rollback_seg          IN VARCHAR2 := NULL,
                              refresh_after_errors  IN BOOLEAN  := FALSE,
                              atomic_refresh        IN BOOLEAN  := TRUE,
                              nested                IN BOOLEAN  := FALSE);

  --  -----------------------------------------------------------------------
  --  Refresh all local snapshots based on a local master table where
  --    1) the table has been modified since it was last successfully refreshed
  --    2) the snapshot is a member of dba_mview_analysis
  --  NOTE:
  --    A snapshot will be considered only if all of its tables are local.
  --
  --   NUMBER_OF_FAILURES
  --     Returns the number of failures that occurred during processing.
  --   METHOD
  --     A single refresh method indicating how to refresh the dependent
  --     snapshots.  If a refresh method is not specified, then any dependent
  --     snapshot is refreshed according to its default refresh method.  The
  --     default refresh method for a snapshot is stored in the data dictionary.
  --     A refresh method is represented by the following codes:
  --     '?' -- use fast refresh if possible;  otherwise, use complete refresh
  --     'F' -- use fast refresh if possible;  otherwise, raise an error
  --     'C' -- use complete refresh to construct the entire snapshot from
  --            the master tables
  --   ROLLBACK_SEG
  --     The name of the rollback segment to use while refreshing the snapshots.
  --   REFRESH_AFTER_ERRORS
  --     If TRUE and if ATOMIC_REFRESH is FALSE, then an error will not be
  --     raised if an error is encountered during the refresh.  Otherwise,
  --     any error encountered during refresh will be raised.
  --   ATOMIC_REFRESH
  --     If TRUE, then refresh all of the dependent snapshots in a single
  --     transaction.  This guarantees that either all of the snapshots are
  --     successfully refreshed or none of the snapshots are refreshed.
  --     Otherwise, refresh each dependent snapshot in a separate transaction.
  PROCEDURE refresh_all_mviews(number_of_failures   OUT BINARY_INTEGER,
                               method                IN VARCHAR2 := NULL,
                               rollback_seg          IN VARCHAR2 := NULL,
                               refresh_after_errors  IN BOOLEAN  := FALSE,
                               atomic_refresh        IN BOOLEAN  := TRUE);

  -- ------------------------------------------------------------------------
  -- This procedure finds the list of materialized view that are directly
  -- dependent on the list of tables or materialized views that has been
  -- specified.
  --
  -- LIST :
  --   A comma separated list of the tables/materialized views to consider
  -- DEPLIST
  --   The list of materialized views that are directly dependent on the
  --   tables/materialized view that has been specified in "LIST".
  --
  PROCEDURE get_mv_dependencies(list		IN VARCHAR2,
 				deplist	       OUT VARCHAR2);

  -- ------------------------------------------------------------------------
  -- This procedure disables or enables snapshot replication trigger at the
  -- local snapshot site.
  -- value = TRUE  -> disable all local replication triggers for snapshots
  -- value = FALSE -> enable all local replication triggers for snapshots
  PROCEDURE set_i_am_a_refresh(value IN BOOLEAN);

  -- ------------------------------------------------------------------------
  -- Returns TRUE if the local site is in the process of refreshing one or
  -- more snapshots. Return FALSE otherwise.
  FUNCTION i_am_a_refresh RETURN BOOLEAN;

  -- ------------------------------------------------------------------------
  -- This procedure must be called before a master table is reorganized. It
  -- performs process to preserve snapshot data needed for refresh.
  PROCEDURE begin_table_reorganization(tabowner IN VARCHAR2,
                                       tabname  IN VARCHAR2);

  -- ------------------------------------------------------------------------
  -- This procedure myst be call after a master tanel is reorganized. It
  -- ensures that the snapshot data for the master table is valid and that
  -- the master table is in the proper state.
  PROCEDURE end_table_reorganization(tabowner IN VARCHAR2,
                                     tabname  IN VARCHAR2);

  -- ------------------------------------------------------------------------
  -- Purge the snapshot log for the specified master master of unecessary rows.
  PROCEDURE purge_log(master IN VARCHAR2,
                      num    IN BINARY_INTEGER := 1,
                      flag   IN VARCHAR2       := 'NOP' );

  -- ------------------------------------------------------------------------
  -- Remove entries from the direct loader log after they are no longer
  -- needed for any known snapshot.
  PROCEDURE purge_direct_load_log;

  -- ------------------------------------------------------------------------
  -- Invoked at the master site by (remote) snapshot site 'snapsite' to
  -- register snapshot 'snapname' at the master site. The invocation
  -- is done using a synchronous RPC.
  -- May also be invoked directly at the master site by the DBA to manually
  -- register a snapshot.
  --
  -- Input argugments:
  --    snapowner   Owner of the snapshot
  --    snapname    Name of the snapshot
  --    snapsite    Name of the snapshot site (should contain no double qoutes)
  --    snapshot_id V7 snapshot identifier
  --    flag        Attributes of the snapshot
  --    qry_txt     Snapshot definition query
  --    rep_type    Version of snapshot
  PROCEDURE register_mview(mviewowner   IN VARCHAR2,
                           mviewname    IN VARCHAR2,
                           mviewsite    IN VARCHAR2,
                           mview_id     IN DATE,
                           flag         IN BINARY_INTEGER,
                           qry_txt      IN VARCHAR2,
			   rep_type     IN BINARY_integer
			                   := dbms_snapshot.reg_unknown);
  -- Input argugments:
  --    snapowner   Owner of the snapshot
  --    snapname    Name of the snapshot
  --    snapsite    Name of the snapshot site (should contain no double qoutes)
  --    snapshot_id snapshot identifier
  --    flag        Attributes of the snapshot
  --    qry_txt     Snapshot definition query
  --    rep_type    Version of snapshot
  PROCEDURE register_mview(mviewowner   IN VARCHAR2,
                           mviewname    IN VARCHAR2,
                           mviewsite    IN VARCHAR2,
                           mview_id     IN BINARY_INTEGER,
                           flag         IN BINARY_INTEGER,
                           qry_txt      IN VARCHAR2,
			   rep_type     IN BINARY_integer
			                   := dbms_snapshot.reg_unknown);

  -- ------------------------------------------------------------------------
  -- Invoked at the master site by (remote) snapshot site 'snapsite' to
  -- unregister snapshot 'snapname' at the master site. The invocation
  -- is done using a synchronous RPC.
  -- May also be invoked directly at the master site by the DBA to manually
  -- register a snapshot.
  --
  -- Input argugments:
  --    snapowner   Owner of the snapshot
  --    snapname    Name of the snapshot
  --    snapsite    Name of the snapshot site (should contain no double qoutes)
  PROCEDURE unregister_mview(mviewowner IN VARCHAR2,
                             mviewname  IN VARCHAR2,
                             mviewsite  IN VARCHAR2);

  -- ------------------------------------------------------------------------
  -- This procedure is called on the master site to delete the rows in
  -- snapshot refresh related data dictionary tables maintained at the
  -- master site for the specified snapshot identified by its snapshot_id.
  -- If the snapshot specified is the oldest snapshot to have refreshed
  -- from any of the  master tables, then the snapshot log is also purged.
  -- This procedure does not unregister the snapshot.
  --
  -- In case there is an error while purging one of the snapshot logs, the
  -- successful purge operations of the previous snapshot logs are not rolled
  -- back. This is to  minimize the size of the snapshot logs. In case of an
  -- error, this procedure can be invoked again until all the snapshot
  -- logs are purged.
  PROCEDURE purge_mview_from_log(mview_id IN BINARY_INTEGER);

  -- ------------------------------------------------------------------------
  -- This procedure is called on the master site to delete the rows in
  -- snapshot refresh related data dictionary tables maintained at the
  -- master site for the specified snapshot. If the snapshot specified is
  -- the oldest snapshot to have refreshed  from any of the master tables,
  -- then the snapshot log is also purged. This procedure does not unregister
  -- the snapshot.
  --
  -- In case there is an error while purging one of the snapshot logs, the
  -- successful purge operations of the previous snapshot logs are not rolled
  -- back. This is to  minimize the size of the snapshot logs. In case of an
  -- error, this procedure can be invoked again until all the snapshot
  -- logs are purged.
  PROCEDURE purge_mview_from_log(mviewowner   IN VARCHAR2,
                                 mviewname    IN VARCHAR2,
                                 mviewsite    IN VARCHAR2);

  FUNCTION pmarker (rid IN ROWID) RETURN NUMBER PARALLEL_ENABLE;


  -- ------------------------------------------------------------------------
  -- Interface for EXPLAIN_MVIEW PROCEDURES
  -- ------------------------------------------------------------------------
  --
  -- ------------------------------------------------------------------------
  -- This procedure explains the various capabilities of a potential
  -- materialized view or an existing materialized view and the reasons
  -- why certain capabilities would not be possible for the materialized
  -- view.  Specify a potential materialized view as a SQL SELECT statement.
  -- Alternatively, specify an existing materialized view by giving the name
  -- and the schema in which the materialized view was created ([schema.]mvname)
  -- The output is placed in MV_CAPABILITIES_TABLE.  Invoke the admin/utlxmv.sql
  -- script to define MV_CAPABILITIES_TABLE prior to invoking this procedure.
  PROCEDURE explain_mview ( mv     IN VARCHAR2,
                           stmt_id IN VARCHAR2 := NULL );

  -- ------------------------------------------------------------------------
  -- This procedure explains the various capabilities of a potential
  -- materialized view or an existing materialized view and the reasons
  -- why certain capabilities would not be possible for the materialized
  -- view.  Specify a potential materialized view as a SQL SELECT statement.
  -- Alternatively, specify an existing materialized view by giving the name
  -- and the schema in which the materialized view was created ([schema.]mvname)
  -- It accepts a CLOB instead of VARCHAR, so users can specify SQL string up
  -- to 4G. The output is placed in MV_CAPABILITIES_TABLE.  Invoke the
  -- admin/utlxmv.sql script to define MV_CAPABILITIES_TABLE prior to invoking
  -- this procedure.
  PROCEDURE explain_mview ( mv     IN CLOB,
                           stmt_id IN VARCHAR2 := NULL );

  -- ------------------------------------------------------------------------
  -- This procedure explains the various capabilities of a potential
  -- materialized view or an existing materialized view and the reasons
  -- why certain capabilities would not be possible for the materialized
  -- view.  Specify a potential materialized view as a SQL SELECT statement.
  -- Alternatively, specify an existing materialized view by giving the name
  -- and the schema in which the materialized view was created ([schema.]mvname)
  -- The output is placed into an VARRAY.
  PROCEDURE explain_mview ( mv        IN     VARCHAR2,
                            msg_array IN OUT SYS.ExplainMVArrayType);

  -- ------------------------------------------------------------------------
  -- This procedure explains the various capabilities of a potential
  -- materialized view or an existing materialized view and the reasons
  -- why certain capabilities would not be possible for the materialized
  -- view.  Specify a potential materialized view as a SQL SELECT statement.
  -- Alternatively, specify an existing materialized view by giving the name
  -- and the schema in which the materialized view was created ([schema.]mvname)
  -- It accepts a CLOB instead of VARCHAR, so users can specify SQL string up to
  -- 4G. The output is placed into an VARRAY.
  PROCEDURE explain_mview ( mv        IN     CLOB,
                            msg_array IN OUT SYS.ExplainMVArrayType);

  -- ------------------------------------------------------------------------
  -- End of user interface for EXPLAIN_MVIEW PROCEDURES
  -- ------------------------------------------------------------------------

  -- ------------------------------------------------------------------------
  -- Interface for EXPLAIN_REWRITE PROCEDURES
  -- ------------------------------------------------------------------------
  --

  -- PROCEDURE EXPLAIN_REWRITE
  --
  -- PURPOSE: Explain Rewrite user interface using a table for output
  --
  -- PARAMETERS
  -- ==========
  --
  -- QUERY       : SQL select statement to be explained
  -- MV          : Fully qualified MV name specified by the user (mv_owner.mv_name)
  -- STATEMENT_ID: a unique id from the user to distinguish output messages
  --
  PROCEDURE Explain_Rewrite ( QUERY IN VARCHAR2,
                              MV IN VARCHAR2 := NULL,
                              STATEMENT_ID IN VARCHAR2 := NULL);

  -- PROCEDURE EXPLAIN_REWRITE
  --
  -- PURPOSE: Explain Rewrite user interface using a table for output. This
  --          overloaded function uses CLOB instead of VARCHAR, so users can
  --          specify a SQL query upto 4GB.
  --
  -- PARAMETERS
  -- ==========
  --
  -- QUERY       : SQL select statement to be explained in CLOB
  -- MV          : Fully qualified MV name specified by the user (mv_owner.mv_name)
  -- STATEMENT_ID: a unique id from the user to distinguish output messages
  --
  PROCEDURE Explain_Rewrite ( QUERY IN CLOB,
                              MV IN VARCHAR2 := NULL,
                              STATEMENT_ID IN VARCHAR2 := NULL);

  --
  -- PROCEDURE EXPLAIN_REWRITE
  --
  -- PURPOSE: Explain Rewrite user interface using a VARRAY for output
  --
  -- PARAMETERS
  -- ==========
  --
  -- QUERY       : SQL select statement to be explained
  -- MV          : Fully qualified MV name specified by the user (mv_owner.mv_name)
  -- MSG_ARRAY   : name of the output array
  --
  PROCEDURE Explain_Rewrite ( QUERY IN VARCHAR2,
                                   MV IN VARCHAR2 := NULL,
                                   MSG_ARRAY IN OUT SYS.RewriteArrayType);

  --
  -- PROCEDURE EXPLAIN_REWRITE
  --
  -- PURPOSE: Explain Rewrite user interface using a VARRAY for output. This
  --          overloaded function uses CLOB instead of VARCHAR, so users can
  --          specify a SQL query upto 4GB.
  --
  -- PARAMETERS
  -- ==========
  --
  -- QUERY       : SQL select statement to be explained in CLOB
  -- MV          : Fully qualified MV name specified by the user (mv_owner.mv_name)
  -- MSG_ARRAY   : name of the output array
  --
  PROCEDURE Explain_Rewrite ( QUERY IN CLOB,
                                   MV IN VARCHAR2 := NULL,
                                   MSG_ARRAY IN OUT SYS.RewriteArrayType);

  -- ------------------------------------------------------------------------
  -- End of user interface for EXPLAIN_REWRITE PROCEDURES
  -- ------------------------------------------------------------------------

  -- ------------------------------------------------------------------------
  -- This estimates the size of a materialized view that you might create,
  -- in bytes and number of rows.
  -- PARAMETERS:
  --      stmt_id: NUMBER
  --            User-specified id
  --      select_clause: VARCHAR2
  --            SQL text for the defining query
  --      num_row: NUMBER
  --            Estimated number of rows
  --      num_col: NUMBER
  --            Estimated number of bytes
  -- COMMENTS:
  --      This procedure requires that 'utlxplan.sql' be executed
  PROCEDURE estimate_mview_size (stmt_id         IN VARCHAR2,
                                 select_clause   IN VARCHAR2,
                                 num_rows        OUT NUMBER,
                                 num_bytes       OUT NUMBER);


  --- #######################################################################
  --- INTERNAL PROCEDURES
  ---
  --- The following procedure provide internal functionality and should
  --- not be called directly.
  ---
  --- #######################################################################

  ---  These interfaces are obselete in V8 and are present only for
  ---  providing backwards compatibility

  PROCEDURE set_up(mowner   IN     VARCHAR2,
                   master   IN     VARCHAR2,
                   log      IN OUT VARCHAR2,
	           snapshot IN OUT DATE,
                   snaptime IN OUT DATE);

  PROCEDURE wrap_up(mowner IN VARCHAR2,
                    master IN VARCHAR2,
                    sshot  IN DATE,
                    stime  IN DATE);

  PROCEDURE get_log_age(oldest IN OUT DATE,
                        mow    IN     VARCHAR2,
                        mas    IN     VARCHAR2);

  -- obselete interface, present for backward compatability
  PROCEDURE drop_snapshot(mowner   IN VARCHAR2,
                          master   IN VARCHAR2,
                          snapshot IN DATE);

  PROCEDURE testing;

  -- Internal Procedure ONLY. DO NOT USE DIRECTLY
  -- Note: added parameter 'resources' for internal parallel resource
  -- load balancing
  PROCEDURE refresh_mv (pipename       IN  VARCHAR2,
                        mv_index       IN  BINARY_INTEGER,
                        owner          IN  VARCHAR2,
                        name           IN  VARCHAR2,
                        method         IN  VARCHAR2,
                        rollseg        IN  VARCHAR2,
                        atomic_refresh IN  BINARY_INTEGER,
                        env            IN BINARY_INTEGER,
                        resources      IN BINARY_INTEGER DEFAULT 0);

  --- #######################################################################
  --- #######################################################################
  ---                        DEPRECATED PROCEDURES
  ---
  --- The following procedures will soon obsolete due to the materialized
  --- view integration with snapshots. They are kept around for backwards
  --- compatibility purposes.
  ---
  --- #######################################################################
  --- #######################################################################
  PROCEDURE register_snapshot(snapowner   IN VARCHAR2,
                  snapname    IN VARCHAR2,
                  snapsite    IN VARCHAR2,
                  snapshot_id IN DATE,
                  flag        IN BINARY_INTEGER,
                  qry_txt     IN VARCHAR2,
                  rep_type    IN BINARY_INTEGER := dbms_snapshot.reg_unknown);

  PROCEDURE register_snapshot(snapowner   IN VARCHAR2,
                  snapname    IN VARCHAR2,
                  snapsite    IN VARCHAR2,
                  snapshot_id IN BINARY_INTEGER,
                  flag        IN BINARY_INTEGER,
                  qry_txt     IN VARCHAR2,
                  rep_type    IN BINARY_INTEGER := dbms_snapshot.reg_unknown);

  PROCEDURE unregister_snapshot(snapowner IN VARCHAR2,
                                snapname  IN VARCHAR2,
                                snapsite  IN VARCHAR2);

  PROCEDURE purge_snapshot_from_log(snapshot_id IN BINARY_INTEGER);

  PROCEDURE purge_snapshot_from_log(snapowner   IN VARCHAR2,
                                    snapname    IN VARCHAR2,
                                    snapsite    IN VARCHAR2);





END dbms_snapshot;
/

