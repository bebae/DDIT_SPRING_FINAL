create PACKAGE dbms_xmlstore AUTHID CURRENT_USER AS

  -- context handle
  SUBTYPE ctxHandle IS NUMBER;
  SUBTYPE ctxType IS NUMBER;
  SUBTYPE conversionType IS NUMBER;

  -------------------- constructor/destructor functions ---------------------
  FUNCTION newContext(targetTable IN VARCHAR2) RETURN ctxHandle;
  PROCEDURE closeContext(ctxHdl IN ctxHandle);

  -- set the row tag name
  PROCEDURE setRowTag(ctx IN ctxHandle, rowTagName IN varchar2);

  -- set the columns to update. Relevant for insert and update routines..
  PROCEDURE setUpdateColumn(ctxHdl IN ctxType, colName IN VARCHAR2);
  PROCEDURE clearUpdateColumnList(ctxHdl IN ctxType);

  -- set the key column name to be used for updates and deletes.
  PROCEDURE setKeyColumn(ctxHdl IN ctxType, colName IN VARCHAR2);
  PROCEDURE clearKeyColumnList(ctxHdl IN ctxType);

  ------------------- save ----------------------------------------------------
  -- insertXML
  FUNCTION  insertXML(ctxHdl IN ctxType, xDoc IN VARCHAR2) RETURN NUMBER;
  FUNCTION  insertXML(ctxHdl IN ctxType, xDoc IN CLOB) RETURN NUMBER;
  FUNCTION  insertXML(ctxHdl IN ctxType, xDoc IN XMLTYPE) RETURN NUMBER;
  -- updateXML
  FUNCTION  updateXML(ctxHdl IN ctxType, xDoc IN VARCHAR2) RETURN NUMBER;
  FUNCTION  updateXML(ctxHdl IN ctxType, xDoc IN CLOB) RETURN NUMBER;
  FUNCTION  updateXML(ctxHdl IN ctxType, xDoc IN XMLTYPE) RETURN NUMBER;
  -- deleteXML
  FUNCTION  deleteXML(ctxHdl IN ctxType, xDoc IN VARCHAR2) RETURN NUMBER;
  FUNCTION  deleteXML(ctxHdl IN ctxType, xDoc IN CLOB) RETURN NUMBER;
  FUNCTION  deleteXML(ctxHdl IN ctxType, xDoc IN XMLTYPE) RETURN NUMBER;

END dbms_xmlstore;
/

