create function dictionary_obj_name return varchar2 is
begin
return dbms_standard.dictionary_obj_name;
end;
/

