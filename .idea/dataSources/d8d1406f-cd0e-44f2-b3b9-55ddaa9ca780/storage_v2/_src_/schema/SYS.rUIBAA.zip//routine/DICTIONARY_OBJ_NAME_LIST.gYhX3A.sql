create function dictionary_obj_name_list
(object_list out ora_name_list_t)
return binary_integer is
begin
return dbms_standard.dictionary_obj_name_list(object_list);
end;
/

