create function is_drop_column (column_name varchar2)
return boolean is
begin
return dbms_standard.is_drop_column(column_name);
end;
/

