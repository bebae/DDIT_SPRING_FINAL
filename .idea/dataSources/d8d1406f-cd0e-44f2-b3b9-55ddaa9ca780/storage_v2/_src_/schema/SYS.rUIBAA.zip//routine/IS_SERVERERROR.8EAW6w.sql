create function is_servererror (errno binary_integer)
return boolean is
begin
return dbms_standard.is_servererror(errno);
end;
/

